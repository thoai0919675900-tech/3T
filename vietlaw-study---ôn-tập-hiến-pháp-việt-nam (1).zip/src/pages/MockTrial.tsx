import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { 
  Gavel, 
  Scale, 
  User, 
  Bot, 
  Send, 
  AlertCircle, 
  CheckCircle2, 
  XCircle,
  Play,
  RotateCcw,
  BookOpen,
  Sparkles,
  ShieldAlert,
  Award
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../utils/utils';

interface TrialMessage {
  role: 'judge' | 'lawyer' | 'system';
  content: string;
  timestamp: string;
}

const MockTrial: React.FC = () => {
  const [gameState, setGameState] = useState<'idle' | 'intro' | 'active' | 'finished'>('idle');
  const [messages, setMessages] = useState<TrialMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [currentCase, setCurrentCase] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const startNewTrial = async () => {
    setGameState('intro');
    setMessages([]);
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      const model = "gemini-3-flash-preview";
      
      const prompt = `Hãy tạo một tình huống pháp lý giả định ngắn gọn (khoảng 100 chữ) liên quan đến Hiến pháp Việt Nam 2013 (ví dụ: quyền tự do ngôn luận, quyền sở hữu tài sản, quyền bầu cử...). 
      Tình huống nên có một tranh chấp cụ thể. 
      Trả lời bằng tiếng Việt. 
      Định dạng: "TÌNH HUỐNG: [Nội dung tình huống]"`;

      const response = await ai.models.generateContent({
        model: model,
        contents: [{ role: 'user', parts: [{ text: prompt }] }]
      });

      const caseText = response.text || "Không thể khởi tạo tình huống. Vui lòng thử lại.";
      setCurrentCase(caseText);
      setMessages([
        {
          role: 'system',
          content: 'Chào mừng bạn đến với Phiên tòa giả định VietLaw. Bạn sẽ đóng vai Luật sư bào chữa hoặc Kiểm sát viên.',
          timestamp: new Date().toISOString()
        },
        {
          role: 'judge',
          content: `Hội đồng xét xử xin công bố tình huống hôm nay: \n\n${caseText}\n\nMời bạn đưa ra lập luận của mình dựa trên các điều khoản của Hiến pháp 2013.`,
          timestamp: new Date().toISOString()
        }
      ]);
      setGameState('active');
    } catch (error) {
      console.error('Trial Start Error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: TrialMessage = {
      role: 'lawyer',
      content: input,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      const model = "gemini-3-flash-preview";
      
      const systemInstruction = `Bạn là Thẩm phán chủ tọa phiên tòa giả định về Hiến pháp Việt Nam 2013. 
      Người dùng đang đóng vai luật sư. 
      Nhiệm vụ của bạn là:
      1. Phân tích lập luận của người dùng dựa trên Hiến pháp 2013.
      2. Đưa ra phản hồi chuyên nghiệp, nghiêm túc nhưng mang tính giáo dục.
      3. Nếu người dùng trích dẫn đúng Điều luật, hãy khen ngợi. Nếu sai, hãy chỉnh sửa.
      4. Sau 3-4 lượt đối thoại, hãy đưa ra PHÁN QUYẾT cuối cùng và kết thúc phiên tòa.
      Khi kết thúc, hãy bắt đầu bằng từ "PHÁN QUYẾT:".`;

      const chatHistory = messages.map(m => ({
        role: m.role === 'lawyer' ? 'user' : 'model',
        parts: [{ text: m.content }]
      }));

      const response = await ai.models.generateContent({
        model: model,
        contents: [...chatHistory, { role: 'user', parts: [{ text: input }] }],
        config: { systemInstruction }
      });

      const judgeResponse = response.text || "Thẩm phán đang suy nghĩ...";
      
      setMessages(prev => [...prev, {
        role: 'judge',
        content: judgeResponse,
        timestamp: new Date().toISOString()
      }]);

      if (judgeResponse.includes('PHÁN QUYẾT:')) {
        setGameState('finished');
        setScore(prev => prev + 100); // Giả định cộng điểm khi hoàn thành
      }
    } catch (error) {
      console.error('Trial Message Error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto h-[calc(100vh-180px)] flex flex-col gap-6">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-sky-600 rounded-2xl shadow-lg shadow-sky-600/20">
            <Gavel className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-black text-white tracking-tight">Phiên Tòa <span className="text-sky-400">Giả Định</span></h1>
            <p className="text-xs font-bold text-sky-300/40 uppercase tracking-widest">Thử thách tư duy pháp lý AI</p>
          </div>
        </div>
        {gameState === 'finished' && (
          <button 
            onClick={startNewTrial}
            className="flex items-center gap-2 px-6 py-2.5 bg-white/5 hover:bg-white/10 text-white rounded-xl border border-white/10 transition-all font-bold text-sm"
          >
            <RotateCcw className="h-4 w-4" />
            Phiên tòa mới
          </button>
        )}
      </header>

      <div className="flex-1 glass-dark rounded-[40px] border border-white/5 shadow-2xl flex flex-col overflow-hidden relative">
        {gameState === 'idle' ? (
          <div className="flex-1 flex flex-col items-center justify-center p-12 text-center space-y-8">
            <div className="relative">
              <div className="absolute inset-0 bg-sky-500/20 blur-[60px] rounded-full" />
              <div className="relative p-8 bg-sky-950/20 rounded-[40px] border border-sky-500/20 shadow-2xl">
                <Scale className="h-20 w-20 text-sky-400" />
              </div>
            </div>
            <div className="max-w-md space-y-4">
              <h2 className="text-3xl font-black text-white">Sẵn sàng tranh tụng?</h2>
              <p className="text-sky-200/40 leading-relaxed">
                Tham gia vào các tình huống pháp lý thực tế, vận dụng Hiến pháp 2013 để bảo vệ công lý trước Hội đồng xét xử AI.
              </p>
            </div>
            <button 
              onClick={startNewTrial}
              disabled={isLoading}
              className="px-10 py-4 bg-sky-600 hover:bg-sky-500 text-white font-black rounded-2xl shadow-xl shadow-sky-600/20 transition-all active:scale-95 flex items-center gap-3 group"
            >
              <Play className="h-5 w-5 fill-current" />
              BẮT ĐẦU PHIÊN TÒA
              <Sparkles className="h-5 w-5 text-sky-300 group-hover:rotate-12 transition-transform" />
            </button>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto p-8 space-y-8 custom-scrollbar relative z-10">
              <AnimatePresence mode="popLayout">
                {messages.map((msg, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 20, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    className={cn(
                      "flex gap-6 max-w-[90%]",
                      msg.role === 'lawyer' ? "ml-auto flex-row-reverse" : "mr-auto",
                      msg.role === 'system' && "max-w-full mx-auto justify-center"
                    )}
                  >
                    {msg.role !== 'system' && (
                      <div className={cn(
                        "w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 shadow-xl border",
                        msg.role === 'judge' ? "bg-sky-950 border-sky-400/30 text-sky-400" : "bg-cyan-600 border-cyan-400/30 text-white"
                      )}>
                        {msg.role === 'judge' ? <Gavel className="h-6 w-6" /> : <User className="h-6 w-6" />}
                      </div>
                    )}
                    
                    <div className={cn(
                      "p-6 rounded-[32px] text-sm leading-relaxed shadow-2xl relative",
                      msg.role === 'lawyer' 
                        ? "bg-cyan-600 text-white rounded-tr-none" 
                        : msg.role === 'judge'
                        ? "bg-sky-950/50 text-sky-100 border border-sky-400/20 rounded-tl-none"
                        : "bg-sky-400/5 text-sky-300/40 text-xs font-bold uppercase tracking-widest border border-sky-400/10 text-center px-8 py-3 rounded-full"
                    )}>
                      {msg.role === 'judge' && (
                        <div className="flex items-center gap-2 mb-3 text-[10px] font-black text-sky-400 uppercase tracking-[0.2em]">
                          <ShieldAlert className="h-3 w-3" />
                          Hội đồng xét xử
                        </div>
                      )}
                      <div className="whitespace-pre-wrap">{msg.content}</div>
                      {msg.role !== 'system' && (
                        <p className="text-[10px] mt-4 opacity-40 font-black uppercase tracking-widest">
                          {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      )}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
              {isLoading && (
                <div className="flex gap-6 mr-auto">
                  <div className="w-12 h-12 rounded-2xl bg-sky-950 border border-sky-400/30 flex items-center justify-center shadow-xl">
                    <Gavel className="h-6 w-6 text-sky-400 animate-pulse" />
                  </div>
                  <div className="p-6 bg-sky-950/50 border border-sky-400/10 rounded-[32px] rounded-tl-none flex gap-2">
                    <div className="w-2 h-2 bg-sky-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <div className="w-2 h-2 bg-sky-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <div className="w-2 h-2 bg-sky-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            <div className="p-8 bg-sky-950/40 backdrop-blur-xl border-t border-sky-400/10 relative z-10">
              {gameState === 'active' ? (
                <div className="flex gap-4">
                  <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="Nhập lập luận của bạn (ví dụ: 'Theo Điều 25 Hiến pháp...')"
                    className="flex-1 bg-sky-950/50 border border-sky-400/10 rounded-2xl px-8 py-5 text-white placeholder:text-sky-300/20 focus:outline-none focus:border-sky-400/50 transition-all shadow-inner"
                  />
                  <button
                    onClick={handleSend}
                    disabled={!input.trim() || isLoading}
                    className="p-5 bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white rounded-2xl shadow-xl shadow-sky-600/20 transition-all active:scale-95"
                  >
                    <Send className="h-6 w-6" />
                  </button>
                </div>
              ) : (
                <div className="text-center py-4">
                  <div className="inline-flex items-center gap-3 px-8 py-4 bg-cyan-500/10 border border-cyan-500/20 rounded-2xl text-cyan-400 font-black uppercase tracking-widest text-xs">
                    <CheckCircle2 className="h-5 w-5" />
                    Phiên tòa đã kết thúc. Phán quyết đã được tuyên.
                  </div>
                </div>
              )}
              <div className="flex items-center gap-8 mt-6 px-2">
                <div className="flex items-center gap-2 text-[10px] font-black text-sky-300/20 uppercase tracking-widest">
                  <BookOpen className="h-3 w-3" />
                  <span>Dựa trên Hiến pháp 2013</span>
                </div>
                <div className="flex items-center gap-2 text-[10px] font-black text-sky-300/20 uppercase tracking-widest">
                  <Scale className="h-3 w-3" />
                  <span>Công bằng & Khách quan</span>
                </div>
                <div className="ml-auto flex items-center gap-2 text-[10px] font-black text-sky-400 uppercase tracking-widest">
                  <Sparkles className="h-3 w-3" />
                  <span>Thẩm phán AI v1.0</span>
                </div>
              </div>
            </div>
          </>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { icon: AlertCircle, label: 'Tình huống', value: 'Ngẫu nhiên' },
          { icon: User, label: 'Vai trò', value: 'Luật sư' },
          { icon: Award, label: 'Điểm tích lũy', value: score },
          { icon: ShieldAlert, label: 'Độ khó', value: 'Chuyên gia' }
        ].map((item, i) => (
          <div key={i} className="glass-dark p-4 rounded-2xl border border-sky-400/10 flex items-center gap-4">
            <div className="p-2 bg-sky-400/5 rounded-xl text-sky-400">
              <item.icon className="h-5 w-5" />
            </div>
            <div>
              <p className="text-[10px] font-black text-sky-300/40 uppercase tracking-widest">{item.label}</p>
              <p className="text-xs font-bold text-white">{item.value}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MockTrial;
