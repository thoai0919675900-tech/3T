import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Search, ArrowRight, CheckCircle } from 'lucide-react';
import { chapters } from '../data/mockData';
import { useProgress } from '../context/ProgressContext';
import { motion } from 'motion/react';

const ChaptersPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const { progress } = useProgress();

  const filteredChapters = chapters.filter(ch => 
    ch.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ch.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-12 pb-20">
      <header className="relative py-20 px-8 rounded-[40px] overflow-hidden bg-sky-950/20 border border-sky-400/10 shadow-2xl text-center">
        <div className="absolute inset-0 bg-gradient-to-b from-sky-600/20 to-transparent pointer-events-none" />
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-[0.05]" />
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative z-10 max-w-2xl mx-auto"
        >
          <span className="px-4 py-1.5 bg-sky-500/10 text-sky-400 text-xs font-black uppercase tracking-[0.2em] rounded-full border border-sky-500/20">
            Hệ thống chuyên đề
          </span>
          <h1 className="text-5xl md:text-6xl font-black text-white mt-6 tracking-tight">
            Chinh phục <span className="text-gradient">Kiến thức</span>
          </h1>
          <p className="text-sky-200/60 mt-6 text-lg leading-relaxed">
            Khám phá 6 chương trọng tâm của Hiến pháp Việt Nam 2013 thông qua hệ thống bài giảng tóm tắt và câu hỏi ôn luyện.
          </p>

          <div className="mt-10 relative max-w-md mx-auto group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-sky-300/40 group-focus-within:text-sky-400 transition-colors" />
            <input
              type="text"
              placeholder="Tìm kiếm chuyên đề..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-4 bg-sky-400/5 backdrop-blur-md border border-sky-400/10 rounded-2xl text-white placeholder-sky-300/20 focus:outline-none focus:ring-2 focus:ring-sky-400/50 transition-all"
            />
          </div>
        </motion.div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredChapters.map((chapter, idx) => {
          const isCompleted = progress?.completedChapters.includes(chapter.id);
          return (
            <motion.div
              key={chapter.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="group relative bg-sky-950/20 backdrop-blur-xl rounded-[32px] border border-sky-400/10 p-8 shadow-xl hover:border-sky-400/30 transition-all flex flex-col overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-8 opacity-[0.03] group-hover:opacity-[0.07] transition-opacity">
                <BookOpen className="h-32 w-32 -mr-8 -mt-8 rotate-12" />
              </div>

              <div className="flex justify-between items-start mb-8 relative z-10">
                <div className="p-4 rounded-2xl bg-sky-500/10 text-sky-400 group-hover:bg-sky-600 group-hover:text-white transition-all duration-500">
                  <BookOpen className="h-7 w-7" />
                </div>
                {isCompleted && (
                  <div className="flex items-center gap-1.5 text-cyan-400 text-xs font-black uppercase tracking-wider bg-cyan-500/10 px-3 py-1.5 rounded-full border border-cyan-500/20">
                    <CheckCircle className="h-3.5 w-3.5" />
                    Hoàn thành
                  </div>
                )}
              </div>

              <div className="relative z-10 flex-1">
                <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-sky-400 transition-colors leading-tight">
                  {chapter.title}
                </h3>
                <p className="text-sky-200/40 text-sm leading-relaxed mb-8">
                  {chapter.description}
                </p>
              </div>

              <div className="flex items-center justify-between pt-6 border-t border-sky-400/10 relative z-10">
                <Link 
                  to={`/chapters/${chapter.id}`}
                  className="text-sm font-bold text-sky-400 hover:text-sky-300 flex items-center gap-2 group/link"
                >
                  Chi tiết <ArrowRight className="h-4 w-4 group-hover/link:translate-x-1 transition-transform" />
                </Link>
                <Link 
                  to={`/quiz?chapter=${chapter.id}`}
                  className="px-4 py-2 bg-sky-400/5 hover:bg-sky-400/10 rounded-xl text-xs font-bold text-sky-300/40 transition-all"
                >
                  Trắc nghiệm
                </Link>
              </div>
            </motion.div>
          );
        })}
      </div>

      {filteredChapters.length === 0 && (
        <div className="text-center py-20">
          <div className="inline-flex items-center justify-center p-6 bg-white/5 rounded-full mb-6">
            <Search className="h-10 w-10 text-zinc-700" />
          </div>
          <h3 className="text-2xl font-bold text-white">Không tìm thấy kết quả</h3>
          <p className="text-zinc-500 mt-2">Thử tìm kiếm với từ khóa khác hoặc xem tất cả chuyên đề.</p>
        </div>
      )}
    </div>
  );
};

export default ChaptersPage;
