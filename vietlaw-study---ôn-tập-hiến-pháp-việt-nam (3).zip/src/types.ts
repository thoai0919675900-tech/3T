export enum UserRole {
  STUDENT = 'student',
  ADMIN = 'admin',
}

export interface User {
  id: string;
  username: string;
  role: UserRole;
  fullName: string;
}

export interface Chapter {
  id: string;
  title: string;
  description: string;
  content: string;
}

export interface Question {
  id: string;
  chapterId: string;
  questionText: string;
  options: string[];
  correctOptionIndex: number;
  explanation: string;
}

export interface Flashcard {
  id: string;
  chapterId: string;
  articleNumber: string;
  content: string;
}

export interface QuizResult {
  id: string;
  userId: string;
  chapterId: string;
  score: number;
  totalQuestions: number;
  date: string;
  type: 'practice' | 'exam';
}

export interface Progress {
  userId: string;
  completedChapters: string[];
  masteredFlashcards: string[];
}

export interface LeaderboardEntry {
  id: string;
  userId: string;
  fullName: string;
  totalScore: number;
  quizzesTaken: number;
  rank: number;
  avatar?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}
