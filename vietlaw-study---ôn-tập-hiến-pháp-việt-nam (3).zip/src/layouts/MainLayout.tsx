import React from 'react';
import { Outlet, Navigate, useLocation } from 'react-router-dom';
import { motion } from 'motion/react';
import { BookOpen } from 'lucide-react';
import Navbar from '../components/Navbar';
import { useAuth } from '../context/AuthContext';

const MainLayout: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const location = useLocation();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return (
    <div className="min-h-screen bg-zinc-950 text-white selection:bg-sky-500/30">
      {/* Immersive background elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-sky-600/10 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-cyan-600/10 blur-[120px] rounded-full" />
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-[0.03]" />
      </div>

      <Navbar />
      
      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-12">
        <motion.div
          key={location.pathname}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: "easeOut" }}
        >
          <Outlet />
        </motion.div>
      </main>

      <footer className="relative z-10 border-t border-sky-400/5 py-12 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-3">
            <div className="bg-sky-950/20 p-2 rounded-xl border border-sky-400/10">
              <BookOpen className="h-5 w-5 text-sky-400" />
            </div>
            <span className="font-black tracking-tighter text-sky-300/40">
              VIETLAW <span className="text-sky-300/20">STUDY</span>
            </span>
          </div>
          <p className="text-sky-300/20 text-sm font-medium">
            &copy; {new Date().getFullYear()} VietLaw Study. Nền tảng ôn tập Hiến pháp hiện đại.
          </p>
          <div className="flex gap-6">
            <a href="#" className="text-sky-300/20 hover:text-white transition-colors text-sm font-bold">Điều khoản</a>
            <a href="#" className="text-sky-300/20 hover:text-white transition-colors text-sm font-bold">Bảo mật</a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default MainLayout;
