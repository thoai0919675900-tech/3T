import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { 
  BookOpen, 
  LayoutDashboard, 
  CheckSquare, 
  CreditCard, 
  LogOut, 
  Menu, 
  X, 
  User,
  ShieldCheck,
  Bot,
  Trophy,
  Timer,
  Play,
  Pause,
  RotateCcw,
  Gavel,
  History
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../types';
import { cn } from '../utils/utils';

const StudyTimer: React.FC = () => {
  const [seconds, setSeconds] = useState(0);
  const [isActive, setIsActive] = useState(false);

  useEffect(() => {
    let interval: any = null;
    if (isActive) {
      interval = setInterval(() => {
        setSeconds((seconds) => seconds + 1);
      }, 1000);
    } else if (!isActive && seconds !== 0) {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [isActive, seconds]);

  const formatTime = (totalSeconds: number) => {
    const hrs = Math.floor(totalSeconds / 3600);
    const mins = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;
    return `${hrs > 0 ? hrs + ':' : ''}${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex items-center gap-3 bg-white/5 border border-white/10 rounded-2xl px-4 py-2">
      <div className="flex items-center gap-2">
        <Timer className={cn("h-4 w-4", isActive ? "text-sky-400 animate-pulse" : "text-zinc-500")} />
        <span className="text-sm font-black text-white tabular-nums w-12">{formatTime(seconds)}</span>
      </div>
      <div className="flex items-center gap-1 border-l border-white/10 pl-2">
        <button 
          onClick={() => setIsActive(!isActive)}
          className="p-1 hover:text-white text-zinc-500 transition-colors"
        >
          {isActive ? <Pause className="h-3 w-3" /> : <Play className="h-3 w-3" />}
        </button>
        <button 
          onClick={() => { setSeconds(0); setIsActive(false); }}
          className="p-1 hover:text-white text-zinc-500 transition-colors"
        >
          <RotateCcw className="h-3 w-3" />
        </button>
      </div>
    </div>
  );
};

const Navbar: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true); // Default to dark for premium feel

  useEffect(() => {
    document.documentElement.classList.add('dark');
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const navItems = [
    { name: 'Tổng quan', path: '/', icon: LayoutDashboard },
    { name: 'Chuyên đề', path: '/chapters', icon: BookOpen },
    { name: 'Trắc nghiệm', path: '/quiz', icon: CheckSquare },
    { name: 'Flashcards', path: '/flashcards', icon: CreditCard },
    { name: 'Trợ lý AI', path: '/ai-assistant', icon: Bot },
    { name: 'Bảng xếp hạng', path: '/leaderboard', icon: Trophy },
    { name: 'Phiên tòa giả định', path: '/mock-trial', icon: Gavel },
    { name: 'Lịch sử Hiến pháp', path: '/timeline', icon: History },
  ];

  if (user?.role === UserRole.ADMIN) {
    navItems.push({ name: 'Quản trị', path: '/admin', icon: ShieldCheck });
  }

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 px-4 py-4 pointer-events-none">
      <div className="max-w-7xl mx-auto pointer-events-auto">
        <div className="glass-dark rounded-3xl px-6 py-3 flex justify-between items-center shadow-2xl">
          <div className="flex items-center gap-8">
            <Link to="/" className="flex items-center gap-3 group">
              <div className="bg-sky-600 p-2 rounded-xl shadow-lg shadow-sky-600/20 group-hover:scale-110 transition-transform">
                <BookOpen className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-black text-white tracking-tighter hidden sm:block">
                VIETLAW <span className="text-sky-400">STUDY</span>
              </span>
            </Link>
            
            <div className="hidden md:flex items-center gap-1">
              {navItems.map((item) => (
                <Link
                  key={item.name}
                  to={item.path}
                  className={cn(
                    "px-4 py-2 rounded-xl text-sm font-bold transition-all flex items-center gap-2",
                    location.pathname === item.path
                      ? "bg-white/10 text-white"
                      : "text-zinc-500 hover:text-white hover:bg-white/5"
                  )}
                >
                  <item.icon className="h-4 w-4" />
                  {item.name}
                </Link>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden lg:block">
              <StudyTimer />
            </div>
            <div className="hidden md:flex items-center gap-4 pl-4 border-l border-white/10">
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <p className="text-sm font-bold text-white leading-none">{user?.fullName}</p>
                  <p className="text-[10px] font-black text-sky-400 uppercase tracking-widest mt-1">
                    {user?.role === UserRole.ADMIN ? 'Quản trị viên' : 'Sinh viên'}
                  </p>
                </div>
                <div className="h-10 w-10 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center">
                  <User className="h-5 w-5 text-zinc-400" />
                </div>
              </div>
              <button
                onClick={handleLogout}
                className="p-2.5 rounded-xl bg-white/5 text-zinc-500 hover:text-red-400 hover:bg-red-500/10 transition-all"
              >
                <LogOut className="h-5 w-5" />
              </button>
            </div>

            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2.5 rounded-xl bg-white/5 text-zinc-400"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden mt-4 pointer-events-auto"
          >
            <div className="glass-dark rounded-[32px] p-6 space-y-2 shadow-2xl border border-white/10">
              {navItems.map((item) => (
                <Link
                  key={item.name}
                  to={item.path}
                  onClick={() => setIsMenuOpen(false)}
                  className={cn(
                    "flex items-center gap-4 p-4 rounded-2xl text-base font-bold transition-all",
                    location.pathname === item.path
                      ? "bg-sky-600 text-white"
                      : "text-zinc-400 hover:bg-white/5 hover:text-white"
                  )}
                >
                  <item.icon className="h-5 w-5" />
                  {item.name}
                </Link>
              ))}
              <div className="pt-4 mt-4 border-t border-white/10">
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-4 p-4 rounded-2xl text-red-400 hover:bg-red-500/10 font-bold transition-all"
                >
                  <LogOut className="h-5 w-5" />
                  Đăng xuất
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
