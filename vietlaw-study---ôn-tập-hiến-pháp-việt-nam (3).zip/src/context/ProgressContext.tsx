import React, { createContext, useContext, useState, useEffect } from 'react';
import { QuizResult, Progress } from '../types';
import { useAuth } from './AuthContext';

interface ProgressContextType {
  results: QuizResult[];
  progress: Progress | null;
  addResult: (result: Omit<QuizResult, 'id' | 'userId' | 'date'>) => void;
  markFlashcardMastered: (id: string) => void;
  isFlashcardMastered: (id: string) => boolean;
}

const ProgressContext = createContext<ProgressContextType | undefined>(undefined);

export const ProgressProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [results, setResults] = useState<QuizResult[]>([]);
  const [progress, setProgress] = useState<Progress | null>(null);

  useEffect(() => {
    if (user) {
      const savedResults = localStorage.getItem(`results_${user.id}`);
      const savedProgress = localStorage.getItem(`progress_${user.id}`);
      
      if (savedResults) setResults(JSON.parse(savedResults));
      if (savedProgress) setProgress(JSON.parse(savedProgress));
      else setProgress({ userId: user.id, completedChapters: [], masteredFlashcards: [] });
    }
  }, [user]);

  const addResult = (resultData: Omit<QuizResult, 'id' | 'userId' | 'date'>) => {
    if (!user) return;

    const newResult: QuizResult = {
      ...resultData,
      id: Math.random().toString(36).substr(2, 9),
      userId: user.id,
      date: new Date().toISOString(),
    };

    const updatedResults = [newResult, ...results];
    setResults(updatedResults);
    localStorage.setItem(`results_${user.id}`, JSON.stringify(updatedResults));

    // Update completed chapters if score is high enough
    if (resultData.score / resultData.totalQuestions >= 0.8 && progress) {
      if (!progress.completedChapters.includes(resultData.chapterId)) {
        const updatedProgress = {
          ...progress,
          completedChapters: [...progress.completedChapters, resultData.chapterId]
        };
        setProgress(updatedProgress);
        localStorage.setItem(`progress_${user.id}`, JSON.stringify(updatedProgress));
      }
    }
  };

  const markFlashcardMastered = (id: string) => {
    if (!user || !progress) return;
    
    const isMastered = progress.masteredFlashcards.includes(id);
    const updatedFlashcards = isMastered 
      ? progress.masteredFlashcards.filter(fid => fid !== id)
      : [...progress.masteredFlashcards, id];

    const updatedProgress = {
      ...progress,
      masteredFlashcards: updatedFlashcards
    };
    setProgress(updatedProgress);
    localStorage.setItem(`progress_${user.id}`, JSON.stringify(updatedProgress));
  };

  const isFlashcardMastered = (id: string) => {
    return progress?.masteredFlashcards.includes(id) || false;
  };

  return (
    <ProgressContext.Provider value={{ results, progress, addResult, markFlashcardMastered, isFlashcardMastered }}>
      { children }
    </ProgressContext.Provider>
  );
};

export const useProgress = () => {
  const context = useContext(ProgressContext);
  if (context === undefined) {
    throw new Error('useProgress must be used within a ProgressProvider');
  }
  return context;
};
