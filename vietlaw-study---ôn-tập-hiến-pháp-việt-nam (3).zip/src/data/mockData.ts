import { Chapter, Question, Flashcard } from '../types';

export const chapters: Chapter[] = [
  {
    id: 'ch1',
    title: 'Chương I: Chế độ chính trị',
    description: 'Các nguyên tắc cơ bản về bản chất nhà nước, chủ quyền nhân dân và hệ thống chính trị.',
    content: 'Nước Cộng hòa xã hội chủ nghĩa Việt Nam là một nước độc lập, có chủ quyền, thống nhất và toàn vẹn lãnh thổ... Tất cả quyền lực nhà nước thuộc về Nhân dân mà nền tảng là liên minh giữa giai cấp công nhân với giai cấp nông dân và đội ngũ trí thức.'
  },
  {
    id: 'ch2',
    title: 'Chương II: Quyền con người, quyền và nghĩa vụ cơ bản của công dân',
    description: 'Các quyền về dân sự, chính trị, kinh tế, văn hóa, xã hội của mọi người và công dân.',
    content: 'Ở nước Cộng hòa xã hội chủ nghĩa Việt Nam, các quyền con người, quyền công dân về chính trị, dân sự, kinh tế, văn hóa, xã hội được công nhận, tôn trọng, bảo vệ, bảo đảm theo Hiến pháp và pháp luật.'
  },
  {
    id: 'ch3',
    title: 'Chương III: Quốc hội',
    description: 'Cơ quan đại biểu cao nhất của Nhân dân, cơ quan quyền lực nhà nước cao nhất.',
    content: 'Quốc hội là cơ quan đại biểu cao nhất của Nhân dân, cơ quan quyền lực nhà nước cao nhất của nước Cộng hòa xã hội chủ nghĩa Việt Nam. Quốc hội thực hiện quyền lập hiến, quyền lập pháp, quyết định các vấn đề quan trọng của đất nước và giám sát tối cao đối với hoạt động của Nhà nước.'
  },
  {
    id: 'ch4',
    title: 'Chương IV: Chủ tịch nước',
    description: 'Người đứng đầu Nhà nước, thay mặt Nhà nước về đối nội và đối ngoại.',
    content: 'Chủ tịch nước là người đứng đầu Nhà nước, thay mặt nước Cộng hòa xã hội chủ nghĩa Việt Nam về đối nội và đối ngoại. Chủ tịch nước do Quốc hội bầu trong số đại biểu Quốc hội.'
  },
  {
    id: 'ch5',
    title: 'Chương V: Chính phủ',
    description: 'Cơ quan hành chính nhà nước cao nhất, thực hiện quyền hành pháp.',
    content: 'Chính phủ là cơ quan hành chính nhà nước cao nhất của nước Cộng hòa xã hội chủ nghĩa Việt Nam, thực hiện quyền hành pháp, là cơ quan chấp hành của Quốc hội.'
  },
  {
    id: 'ch6',
    title: 'Chương VI: Tòa án nhân dân & Viện kiểm sát nhân dân',
    description: 'Cơ quan xét xử và cơ quan thực hành quyền công tố, kiểm sát hoạt động tư pháp.',
    content: 'Tòa án nhân dân là cơ quan xét xử của nước Cộng hòa xã hội chủ nghĩa Việt Nam, thực hiện quyền tư pháp. Viện kiểm sát nhân dân thực hành quyền công tố, kiểm sát hoạt động tư pháp.'
  },
  {
    id: 'ch7',
    title: 'Luật Doanh nghiệp 2020',
    description: 'Quy định về việc thành lập, tổ chức quản lý, tổ chức lại, giải thể và hoạt động có liên quan của doanh nghiệp.',
    content: 'Luật này quy định về việc thành lập, tổ chức quản lý, tổ chức lại, giải thể và hoạt động có liên quan của doanh nghiệp, bao gồm công ty trách nhiệm hữu hạn, công ty cổ phần, công ty hợp danh và doanh nghiệp tư nhân; quy định về nhóm công ty.'
  },
  {
    id: 'ch8',
    title: 'Bộ luật Hình sự 2015',
    description: 'Quy định về tội phạm và hình phạt nhằm bảo vệ các quyền và lợi ích hợp pháp.',
    content: 'Bộ luật Hình sự quy định về tội phạm và hình phạt. Tội phạm là hành vi nguy hiểm cho xã hội được quy định trong Bộ luật Hình sự, do người có năng lực trách nhiệm hình sự hoặc pháp nhân thương mại thực hiện một cách cố ý hoặc vô ý.'
  },
  {
    id: 'ch9',
    title: 'Bộ luật Dân sự 2015',
    description: 'Quy định về địa vị pháp lý, quyền và nghĩa vụ về nhân thân và tài sản.',
    content: 'Bộ luật Dân sự quy định địa vị pháp lý, chuẩn mực hành xử của cá nhân, pháp nhân; quyền, nghĩa vụ về nhân thân và tài sản của cá nhân, pháp nhân trong các quan hệ được hình thành trên cơ sở bình đẳng, tự do tự nguyện.'
  }
];

// Generating some sample questions for Chapter 1
export const questions: Question[] = [
  {
    id: 'q1',
    chapterId: 'ch1',
    questionText: 'Theo Hiến pháp 2013, nước Cộng hòa xã hội chủ nghĩa Việt Nam là một nước?',
    options: [
      'Độc lập, có chủ quyền, thống nhất và toàn vẹn lãnh thổ',
      'Độc lập, tự do, hạnh phúc',
      'Dân giàu, nước mạnh, dân chủ, công bằng, văn minh',
      'Có nền kinh tế phát triển nhất khu vực'
    ],
    correctOptionIndex: 0,
    explanation: 'Điều 1 Hiến pháp 2013 khẳng định: Nước Cộng hòa xã hội chủ nghĩa Việt Nam là một nước độc lập, có chủ quyền, thống nhất và toàn vẹn lãnh thổ, bao gồm đất liền, hải đảo, vùng biển và vùng trời.'
  },
  {
    id: 'q2',
    chapterId: 'ch1',
    questionText: 'Tất cả quyền lực nhà nước thuộc về ai?',
    options: [
      'Đảng Cộng sản Việt Nam',
      'Quốc hội',
      'Nhân dân',
      'Chính phủ'
    ],
    correctOptionIndex: 2,
    explanation: 'Điều 2 Hiến pháp 2013 quy định: Nhà nước Cộng hòa xã hội chủ nghĩa Việt Nam là nhà nước pháp quyền xã hội chủ nghĩa của Nhân dân, do Nhân dân, vì Nhân dân. Tất cả quyền lực nhà nước thuộc về Nhân dân.'
  },
  {
    id: 'q3',
    chapterId: 'ch1',
    questionText: 'Đảng Cộng sản Việt Nam là?',
    options: [
      'Cơ quan quyền lực nhà nước cao nhất',
      'Lực lượng lãnh đạo Nhà nước và xã hội',
      'Cơ quan hành chính nhà nước cao nhất',
      'Cơ quan xét xử của nước Cộng hòa xã hội chủ nghĩa Việt Nam'
    ],
    correctOptionIndex: 1,
    explanation: 'Điều 4 Hiến pháp 2013 quy định: Đảng Cộng sản Việt Nam... là lực lượng lãnh đạo Nhà nước và xã hội.'
  },
  {
    id: 'q4',
    chapterId: 'ch2',
    questionText: 'Quyền con người, quyền công dân chỉ có thể bị hạn chế theo quy định của luật trong trường hợp cần thiết vì lý do?',
    options: [
      'Quốc phòng, an ninh quốc gia, trật tự, an toàn xã hội, đạo đức xã hội, sức khỏe của cộng đồng',
      'Yêu cầu của cơ quan công an',
      'Khi có lệnh của Chủ tịch nước',
      'Để đảm bảo phát triển kinh tế'
    ],
    correctOptionIndex: 0,
    explanation: 'Điều 14 Hiến pháp 2013 quy định các lý do hạn chế quyền con người, quyền công dân.'
  },
  {
    id: 'q5',
    chapterId: 'ch3',
    questionText: 'Nhiệm kỳ của mỗi khóa Quốc hội là mấy năm?',
    options: [
      '4 năm',
      '5 năm',
      '6 năm',
      '3 năm'
    ],
    correctOptionIndex: 1,
    explanation: 'Điều 71 Hiến pháp 2013 quy định: Nhiệm kỳ của mỗi khóa Quốc hội là năm năm.'
  },
  {
    id: 'q6',
    chapterId: 'ch4',
    questionText: 'Chủ tịch nước do ai bầu?',
    options: [
      'Nhân dân bầu trực tiếp',
      'Chính phủ bầu',
      'Quốc hội bầu trong số đại biểu Quốc hội',
      'Ủy ban Thường vụ Quốc hội bầu'
    ],
    correctOptionIndex: 2,
    explanation: 'Điều 87 Hiến pháp 2013 quy định: Chủ tịch nước do Quốc hội bầu trong số đại biểu Quốc hội.'
  },
  {
    id: 'q7',
    chapterId: 'ch5',
    questionText: 'Chính phủ do ai thành lập?',
    options: [
      'Chủ tịch nước',
      'Quốc hội',
      'Đảng Cộng sản Việt Nam',
      'Nhân dân bầu trực tiếp'
    ],
    correctOptionIndex: 1,
    explanation: 'Chính phủ là cơ quan chấp hành của Quốc hội, do Quốc hội thành lập.'
  },
  {
    id: 'q8',
    chapterId: 'ch6',
    questionText: 'Cơ quan nào thực hiện quyền tư pháp?',
    options: [
      'Viện kiểm sát nhân dân',
      'Bộ Tư pháp',
      'Tòa án nhân dân',
      'Chính phủ'
    ],
    correctOptionIndex: 2,
    explanation: 'Điều 102 Hiến pháp 2013 quy định: Tòa án nhân dân là cơ quan xét xử của nước Cộng hòa xã hội chủ nghĩa Việt Nam, thực hiện quyền tư pháp.'
  },
  {
    id: 'q9',
    chapterId: 'ch1',
    questionText: 'Ngôn ngữ quốc gia của nước Cộng hòa xã hội chủ nghĩa Việt Nam là?',
    options: [
      'Tiếng Việt',
      'Tiếng Anh',
      'Tiếng Pháp',
      'Tiếng Nga'
    ],
    correctOptionIndex: 0,
    explanation: 'Điều 5 Hiến pháp 2013 quy định: Ngôn ngữ quốc gia là tiếng Việt.'
  },
  {
    id: 'q10',
    chapterId: 'ch1',
    questionText: 'Quốc kỳ nước Cộng hòa xã hội chủ nghĩa Việt Nam có hình gì?',
    options: [
      'Hình chữ nhật, chiều rộng bằng hai phần ba chiều dài, nền đỏ, ở giữa có ngôi sao vàng năm cánh',
      'Hình vuông, nền đỏ, ở giữa có ngôi sao vàng năm cánh',
      'Hình chữ nhật, nền vàng, có ba sọc đỏ',
      'Hình tròn, nền đỏ, ở giữa có ngôi sao vàng'
    ],
    correctOptionIndex: 0,
    explanation: 'Điều 13 Hiến pháp 2013 quy định về Quốc kỳ.'
  },
  {
    id: 'q11',
    chapterId: 'ch2',
    questionText: 'Công dân có quyền tự do ngôn luận, tự do báo chí, tiếp cận thông tin, hội họp, lập hội, biểu tình theo?',
    options: [
      'Quy định của Chính phủ',
      'Quy định của pháp luật',
      'Quy định của Bộ Công an',
      'Quy định của địa phương'
    ],
    correctOptionIndex: 1,
    explanation: 'Điều 25 Hiến pháp 2013 quy định các quyền này được thực hiện theo quy định của pháp luật.'
  },
  {
    id: 'q12',
    chapterId: 'ch3',
    questionText: 'Cơ quan nào có quyền bãi bỏ văn bản của Chính phủ trái với Hiến pháp, luật, nghị quyết của Quốc hội?',
    options: [
      'Chủ tịch nước',
      'Tòa án nhân dân tối cao',
      'Quốc hội',
      'Viện kiểm sát nhân dân tối cao'
    ],
    correctOptionIndex: 2,
    explanation: 'Quốc hội có quyền bãi bỏ văn bản của Chính phủ trái với Hiến pháp, luật, nghị quyết của Quốc hội.'
  },
  {
    id: 'q13',
    chapterId: 'ch4',
    questionText: 'Chủ tịch nước có quyền thống lĩnh lực lượng vũ trang nhân dân và giữ chức vụ gì?',
    options: [
      'Tổng Tư lệnh quân đội',
      'Chủ tịch Hội đồng quốc phòng và an ninh',
      'Tổng Bí thư',
      'Thủ tướng Chính phủ'
    ],
    correctOptionIndex: 1,
    explanation: 'Điều 88 Hiến pháp 2013 quy định Chủ tịch nước giữ chức Chủ tịch Hội đồng quốc phòng và an ninh.'
  },
  {
    id: 'q14',
    chapterId: 'ch5',
    questionText: 'Thủ tướng Chính phủ do ai bầu?',
    options: [
      'Chủ tịch nước bổ nhiệm',
      'Quốc hội bầu trong số đại biểu Quốc hội',
      'Nhân dân bầu trực tiếp',
      'Chính phủ bầu'
    ],
    correctOptionIndex: 1,
    explanation: 'Điều 98 Hiến pháp 2013 quy định Thủ tướng Chính phủ do Quốc hội bầu trong số đại biểu Quốc hội.'
  },
  {
    id: 'q15',
    chapterId: 'ch6',
    questionText: 'Nguyên tắc xét xử của Tòa án nhân dân là?',
    options: [
      'Xét xử kín',
      'Xét xử công khai, trừ trường hợp luật quy định khác',
      'Xét xử theo yêu cầu của bị cáo',
      'Xét xử theo chỉ đạo của cấp trên'
    ],
    correctOptionIndex: 1,
    explanation: 'Điều 103 Hiến pháp 2013 quy định Tòa án nhân dân xét xử công khai.'
  },
  {
    id: 'q16',
    chapterId: 'ch1',
    questionText: 'Thủ đô của nước Cộng hòa xã hội chủ nghĩa Việt Nam là?',
    options: [
      'Thành phố Hồ Chí Minh',
      'Đà Nẵng',
      'Hà Nội',
      'Huế'
    ],
    correctOptionIndex: 2,
    explanation: 'Điều 13 Hiến pháp 2013 quy định Thủ đô là Hà Nội.'
  },
  {
    id: 'q17',
    chapterId: 'ch7',
    questionText: 'Theo Luật Doanh nghiệp 2020, doanh nghiệp là?',
    options: [
      'Tổ chức có tên riêng, có tài sản, có trụ sở giao dịch, được đăng ký thành lập theo quy định của pháp luật nhằm mục đích kinh doanh',
      'Cơ quan nhà thực hiện chức năng quản lý kinh tế',
      'Tổ chức chính trị - xã hội thực hiện hoạt động thiện nguyện',
      'Cá nhân thực hiện hoạt động mua bán nhỏ lẻ'
    ],
    correctOptionIndex: 0,
    explanation: 'Khoản 10 Điều 4 Luật Doanh nghiệp 2020 định nghĩa về doanh nghiệp.'
  },
  {
    id: 'q18',
    chapterId: 'ch7',
    questionText: 'Công ty trách nhiệm hữu hạn hai thành viên trở lên có số lượng thành viên tối đa là bao nhiêu?',
    options: [
      '20 thành viên',
      '50 thành viên',
      '100 thành viên',
      'Không giới hạn'
    ],
    correctOptionIndex: 1,
    explanation: 'Điều 46 Luật Doanh nghiệp 2020 quy định số lượng thành viên của công ty TNHH hai thành viên trở lên không vượt quá 50.'
  },
  {
    id: 'q19',
    chapterId: 'ch8',
    questionText: 'Theo Bộ luật Hình sự 2015, tội phạm là hành vi?',
    options: [
      'Nguy hiểm cho xã hội được quy định trong Bộ luật Hình sự',
      'Vi phạm nội quy cơ quan, tổ chức',
      'Vi phạm các quy tắc đạo đức thông thường',
      'Gây thiệt hại về tài sản nhưng không đáng kể'
    ],
    correctOptionIndex: 0,
    explanation: 'Điều 8 Bộ luật Hình sự 2015 định nghĩa về tội phạm.'
  },
  {
    id: 'q20',
    chapterId: 'ch8',
    questionText: 'Tuổi chịu trách nhiệm hình sự đối với mọi tội phạm là từ bao nhiêu tuổi trở lên?',
    options: [
      '14 tuổi',
      '16 tuổi',
      '18 tuổi',
      '21 tuổi'
    ],
    correctOptionIndex: 1,
    explanation: 'Điều 12 Bộ luật Hình sự 2015 quy định người từ đủ 16 tuổi trở lên phải chịu trách nhiệm hình sự về mọi tội phạm.'
  },
  {
    id: 'q21',
    chapterId: 'ch9',
    questionText: 'Năng lực hành vi dân sự của cá nhân là?',
    options: [
      'Khả năng của cá nhân có quyền dân sự và nghĩa vụ dân sự',
      'Khả năng của cá nhân bằng hành vi của mình xác lập, thực hiện quyền, nghĩa vụ dân sự',
      'Khả năng của cá nhân được hưởng các quyền lợi từ nhà nước',
      'Khả năng của cá nhân tham gia vào các hoạt động chính trị'
    ],
    correctOptionIndex: 1,
    explanation: 'Điều 19 Bộ luật Dân sự 2015 định nghĩa về năng lực hành vi dân sự.'
  },
  {
    id: 'q22',
    chapterId: 'ch9',
    questionText: 'Người từ đủ bao nhiêu tuổi trở lên có năng lực hành vi dân sự đầy đủ?',
    options: [
      '16 tuổi',
      '18 tuổi',
      '20 tuổi',
      '21 tuổi'
    ],
    correctOptionIndex: 1,
    explanation: 'Điều 20 Bộ luật Dân sự 2015 quy định người thành niên (từ đủ 18 tuổi) có năng lực hành vi dân sự đầy đủ.'
  }
];

export const flashcards: Flashcard[] = [
  {
    id: 'f1',
    chapterId: 'ch1',
    articleNumber: 'Điều 1',
    content: 'Nước Cộng hòa xã hội chủ nghĩa Việt Nam là một nước độc lập, có chủ quyền, thống nhất và toàn vẹn lãnh thổ, bao gồm đất liền, hải đảo, vùng biển và vùng trời.'
  },
  {
    id: 'f2',
    chapterId: 'ch1',
    articleNumber: 'Điều 2',
    content: 'Nhà nước Cộng hòa xã hội chủ nghĩa Việt Nam là nhà nước pháp quyền xã hội chủ nghĩa của Nhân dân, do Nhân dân, vì Nhân dân.'
  },
  {
    id: 'f3',
    chapterId: 'ch1',
    articleNumber: 'Điều 4',
    content: 'Đảng Cộng sản Việt Nam là lực lượng lãnh đạo Nhà nước và xã hội.'
  },
  {
    id: 'f4',
    chapterId: 'ch2',
    articleNumber: 'Điều 16',
    content: 'Mọi người đều bình đẳng trước pháp luật. Không ai bị phân biệt đối xử trong đời sống chính trị, dân sự, kinh tế, văn hóa, xã hội.'
  },
  {
    id: 'f5',
    chapterId: 'ch2',
    articleNumber: 'Điều 19',
    content: 'Mọi người có quyền sống. Tính mạng con người được pháp luật bảo hộ. Không ai bị tước đoạt tính mạng trái luật.'
  },
  {
    id: 'f6',
    chapterId: 'ch3',
    articleNumber: 'Điều 69',
    content: 'Quốc hội là cơ quan đại biểu cao nhất của Nhân dân, cơ quan quyền lực nhà nước cao nhất của nước Cộng hòa xã hội chủ nghĩa Việt Nam.'
  },
  {
    id: 'f7',
    chapterId: 'ch4',
    articleNumber: 'Điều 86',
    content: 'Chủ tịch nước là người đứng đầu Nhà nước, thay mặt nước Cộng hòa xã hội chủ nghĩa Việt Nam về đối nội và đối ngoại.'
  },
  {
    id: 'f8',
    chapterId: 'ch5',
    articleNumber: 'Điều 94',
    content: 'Chính phủ là cơ quan hành chính nhà nước cao nhất của nước Cộng hòa xã hội chủ nghĩa Việt Nam, thực hiện quyền hành pháp, là cơ quan chấp hành của Quốc hội.'
  },
  {
    id: 'f9',
    chapterId: 'ch6',
    articleNumber: 'Điều 102',
    content: 'Tòa án nhân dân là cơ quan xét xử của nước Cộng hòa xã hội chủ nghĩa Việt Nam, thực hiện quyền tư pháp.'
  },
  {
    id: 'f10',
    chapterId: 'ch6',
    articleNumber: 'Điều 107',
    content: 'Viện kiểm sát nhân dân thực hành quyền công tố, kiểm sát hoạt động tư pháp.'
  },
  {
    id: 'f11',
    chapterId: 'ch7',
    articleNumber: 'Điều 4',
    content: 'Kinh doanh là việc thực hiện liên tục một, một số hoặc tất cả các công đoạn của quá trình từ đầu tư, sản xuất đến tiêu thụ sản phẩm hoặc cung ứng dịch vụ trên thị trường nhằm mục đích tìm kiếm lợi nhuận.'
  },
  {
    id: 'f12',
    chapterId: 'ch7',
    articleNumber: 'Điều 17',
    content: 'Tổ chức, cá nhân có quyền thành lập và quản lý doanh nghiệp tại Việt Nam theo quy định của Luật này, trừ trường hợp quy định tại khoản 2 Điều này.'
  },
  {
    id: 'f13',
    chapterId: 'ch8',
    articleNumber: 'Điều 8',
    content: 'Tội phạm là hành vi nguy hiểm cho xã hội được quy định trong Bộ luật Hình sự, do người có năng lực trách nhiệm hình sự hoặc pháp nhân thương mại thực hiện một cách cố ý hoặc vô ý.'
  },
  {
    id: 'f14',
    chapterId: 'ch8',
    articleNumber: 'Điều 27',
    content: 'Thời hiệu truy cứu trách nhiệm hình sự là thời hạn do Bộ luật này quy định mà khi hết thời hạn đó thì người phạm tội không bị truy cứu trách nhiệm hình sự.'
  },
  {
    id: 'f15',
    chapterId: 'ch9',
    articleNumber: 'Điều 3',
    content: 'Mọi cá nhân, pháp nhân đều bình đẳng, không được lấy bất kỳ lý do nào để phân biệt đối xử; được pháp luật bảo hộ như nhau về các quyền nhân thân và tài sản.'
  },
  {
    id: 'f16',
    chapterId: 'ch9',
    articleNumber: 'Điều 16',
    content: 'Năng lực pháp luật dân sự của cá nhân là khả năng của cá nhân có quyền dân sự và nghĩa vụ dân sự. Mọi cá nhân đều có năng lực pháp luật dân sự như nhau.'
  }
];
