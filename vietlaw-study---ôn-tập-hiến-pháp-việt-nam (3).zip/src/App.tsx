import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ProgressProvider } from './context/ProgressContext';
import MainLayout from './layouts/MainLayout';
import LoginPage from './pages/LoginPage';
import Dashboard from './pages/Dashboard';
import ChaptersPage from './pages/ChaptersPage';
import ChapterDetailPage from './pages/ChapterDetailPage';
import QuizPage from './pages/QuizPage';
import FlashcardsPage from './pages/FlashcardsPage';
import AIAssistant from './pages/AIAssistant';
import Leaderboard from './pages/Leaderboard';
import MockTrial from './pages/MockTrial';
import ConstitutionalTimeline from './pages/ConstitutionalTimeline';
import AdminPage from './pages/AdminPage';

export default function App() {
  return (
    <AuthProvider>
      <ProgressProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<LoginPage />} />
            
            <Route path="/" element={<MainLayout />}>
              <Route index element={<Dashboard />} />
              <Route path="chapters" element={<ChaptersPage />} />
              <Route path="chapters/:id" element={<ChapterDetailPage />} />
              <Route path="quiz" element={<QuizPage />} />
              <Route path="flashcards" element={<FlashcardsPage />} />
              <Route path="ai-assistant" element={<AIAssistant />} />
              <Route path="leaderboard" element={<Leaderboard />} />
              <Route path="mock-trial" element={<MockTrial />} />
              <Route path="timeline" element={<ConstitutionalTimeline />} />
              <Route path="admin" element={<AdminPage />} />
            </Route>

            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
      </ProgressProvider>
    </AuthProvider>
  );
}
