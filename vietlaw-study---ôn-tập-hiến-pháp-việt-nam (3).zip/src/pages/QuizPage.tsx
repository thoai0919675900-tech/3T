import React, { useState, useEffect, useMemo } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { 
  CheckCircle2, 
  XCircle, 
  Clock, 
  ArrowRight, 
  ArrowLeft, 
  RotateCcw, 
  Trophy,
  AlertCircle,
  HelpCircle
} from 'lucide-react';
import { questions, chapters } from '../data/mockData';
import { useProgress } from '../context/ProgressContext';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../utils/utils';

const QuizPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { addResult } = useProgress();
  
  const chapterId = searchParams.get('chapter');
  const mode = searchParams.get('mode') as 'practice' | 'exam' || 'practice';

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOptions, setSelectedOptions] = useState<Record<number, number>>({});
  const [showExplanation, setShowExplanation] = useState(false);
  const [isFinished, setIsFinished] = useState(false);
  const [timeLeft, setTimeLeft] = useState(mode === 'exam' ? 1200 : 0); // 20 mins for exam
  const [quizStarted, setQuizStarted] = useState(false);

  const quizQuestions = useMemo(() => {
    let filtered = chapterId 
      ? questions.filter(q => q.chapterId === chapterId)
      : questions;
    
    // Shuffle and pick 15 for practice, 20 for exam
    const count = mode === 'exam' ? 20 : 15;
    return [...filtered].sort(() => Math.random() - 0.5).slice(0, count);
  }, [chapterId, mode]);

  useEffect(() => {
    let timer: any;
    if (quizStarted && mode === 'exam' && timeLeft > 0 && !isFinished) {
      timer = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && mode === 'exam') {
      handleFinish();
    }
    return () => clearInterval(timer);
  }, [quizStarted, timeLeft, mode, isFinished]);

  const handleOptionSelect = (optionIndex: number) => {
    if (isFinished) return;
    
    setSelectedOptions(prev => ({
      ...prev,
      [currentQuestionIndex]: optionIndex
    }));

    if (mode === 'practice') {
      setShowExplanation(true);
    }
  };

  const handleNext = () => {
    if (currentQuestionIndex < quizQuestions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setShowExplanation(false);
    } else {
      handleFinish();
    }
  };

  const handleFinish = () => {
    setIsFinished(true);
    const score = quizQuestions.reduce((acc, q, idx) => {
      return acc + (selectedOptions[idx] === q.correctOptionIndex ? 1 : 0);
    }, 0);

    addResult({
      chapterId: chapterId || 'all',
      score,
      totalQuestions: quizQuestions.length,
      type: mode
    });
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (!quizStarted) {
    return (
      <div className="max-w-2xl mx-auto text-center py-12">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-sky-950/20 p-8 rounded-2xl border border-sky-400/10 shadow-sm"
        >
          <div className="inline-flex items-center justify-center p-4 bg-sky-500/10 text-sky-400 rounded-2xl mb-6">
            <Trophy className="h-10 w-10" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-4">
            {mode === 'exam' ? 'Chế độ Thi thử' : 'Chế độ Luyện tập'}
          </h1>
          <p className="text-sky-200/60 mb-8">
            {mode === 'exam' 
              ? 'Bạn sẽ có 20 câu hỏi và 20 phút để hoàn thành. Kết quả sẽ được lưu vào hệ thống.'
              : 'Bạn sẽ có 15 câu hỏi luyện tập không giới hạn thời gian. Bạn sẽ nhận được giải thích ngay sau mỗi câu hỏi.'}
          </p>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
            <div className="p-4 bg-sky-400/5 rounded-xl text-left">
              <p className="text-xs text-sky-300/40 uppercase font-bold mb-1">Số câu hỏi</p>
              <p className="text-lg font-bold text-white">{quizQuestions.length} câu</p>
            </div>
            <div className="p-4 bg-sky-400/5 rounded-xl text-left">
              <p className="text-xs text-sky-300/40 uppercase font-bold mb-1">Thời gian</p>
              <p className="text-lg font-bold text-white">
                {mode === 'exam' ? '20 phút' : 'Không giới hạn'}
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <button
              onClick={() => navigate('/chapters')}
              className="flex-1 px-6 py-3 bg-sky-400/5 text-white rounded-xl font-semibold hover:bg-sky-400/10 transition-all"
            >
              Quay lại
            </button>
            <button
              onClick={() => setQuizStarted(true)}
              className="flex-1 px-6 py-3 bg-sky-600 text-white rounded-xl font-semibold hover:bg-sky-500 transition-all shadow-lg shadow-sky-600/20"
            >
              Bắt đầu ngay
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  if (isFinished) {
    const score = quizQuestions.reduce((acc, q, idx) => {
      return acc + (selectedOptions[idx] === q.correctOptionIndex ? 1 : 0);
    }, 0);
    const percentage = Math.round((score / quizQuestions.length) * 100);

    return (
      <div className="max-w-2xl mx-auto py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-sky-950/20 p-8 rounded-2xl border border-sky-400/10 shadow-sm text-center"
        >
          <div className="mb-6">
            {percentage >= 80 ? (
              <div className="inline-flex items-center justify-center p-4 bg-cyan-500/10 text-cyan-400 rounded-full">
                <Trophy className="h-12 w-12" />
              </div>
            ) : percentage >= 50 ? (
              <div className="inline-flex items-center justify-center p-4 bg-sky-500/10 text-sky-400 rounded-full">
                <CheckCircle2 className="h-12 w-12" />
              </div>
            ) : (
              <div className="inline-flex items-center justify-center p-4 bg-sky-500/10 text-sky-400 rounded-full">
                <AlertCircle className="h-12 w-12" />
              </div>
            )}
          </div>

          <h2 className="text-3xl font-bold text-white mb-2">
            {percentage >= 80 ? 'Xuất sắc!' : percentage >= 50 ? 'Khá tốt!' : 'Cần cố gắng thêm!'}
          </h2>
          <p className="text-sky-200/60 mb-8">
            Bạn đã hoàn thành bài {mode === 'exam' ? 'thi thử' : 'luyện tập'}.
          </p>

          <div className="grid grid-cols-3 gap-4 mb-8">
            <div className="p-4 bg-sky-400/5 rounded-xl">
              <p className="text-xs text-sky-300/40 uppercase font-bold mb-1">Điểm số</p>
              <p className="text-2xl font-bold text-sky-400">{score}/{quizQuestions.length}</p>
            </div>
            <div className="p-4 bg-sky-400/5 rounded-xl">
              <p className="text-xs text-sky-300/40 uppercase font-bold mb-1">Tỉ lệ</p>
              <p className="text-2xl font-bold text-cyan-400">{percentage}%</p>
            </div>
            <div className="p-4 bg-sky-400/5 rounded-xl">
              <p className="text-xs text-sky-300/40 uppercase font-bold mb-1">Kết quả</p>
              <p className={cn(
                "text-2xl font-bold",
                percentage >= 50 ? "text-cyan-400" : "text-red-400"
              )}>
                {percentage >= 50 ? 'ĐẠT' : 'TRƯỢT'}
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <button
              onClick={() => {
                setIsFinished(false);
                setCurrentQuestionIndex(0);
                setSelectedOptions({});
                setQuizStarted(false);
              }}
              className="flex-1 px-6 py-3 bg-sky-400/5 text-white rounded-xl font-semibold hover:bg-sky-400/10 transition-all flex items-center justify-center gap-2"
            >
              <RotateCcw className="h-5 w-5" />
              Làm lại
            </button>
            <button
              onClick={() => navigate('/')}
              className="flex-1 px-6 py-3 bg-sky-600 text-white rounded-xl font-semibold hover:bg-sky-500 transition-all flex items-center justify-center gap-2"
            >
              Về Dashboard
              <ArrowRight className="h-5 w-5" />
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  const currentQuestion = quizQuestions[currentQuestionIndex];
  const progressPercentage = ((currentQuestionIndex + 1) / quizQuestions.length) * 100;

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center justify-between bg-sky-950/20 p-4 rounded-2xl border border-sky-400/10 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="h-10 w-10 rounded-full bg-sky-500/10 flex items-center justify-center text-sky-400 font-bold">
            {currentQuestionIndex + 1}
          </div>
          <div>
            <p className="text-xs text-sky-300/40 uppercase font-bold">Tiến độ</p>
            <p className="text-sm font-bold text-white">
              Câu {currentQuestionIndex + 1} / {quizQuestions.length}
            </p>
          </div>
        </div>
        
        {mode === 'exam' && (
          <div className={cn(
            "flex items-center gap-2 px-4 py-2 rounded-xl font-mono font-bold",
            timeLeft < 60 ? "bg-red-500/10 text-red-400 animate-pulse" : "bg-sky-400/5 text-white"
          )}>
            <Clock className="h-5 w-5" />
            {formatTime(timeLeft)}
          </div>
        )}
      </div>

      <div className="w-full bg-sky-900/50 h-2 rounded-full overflow-hidden">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${progressPercentage}%` }}
          className="bg-sky-400 h-full"
        />
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={currentQuestionIndex}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="bg-sky-950/20 p-8 rounded-2xl border border-sky-400/10 shadow-sm"
        >
          <h2 className="text-xl font-bold text-white mb-8 leading-relaxed">
            {currentQuestion.questionText}
          </h2>

          <div className="space-y-4">
            {currentQuestion.options.map((option, idx) => {
              const isSelected = selectedOptions[currentQuestionIndex] === idx;
              const isCorrect = idx === currentQuestion.correctOptionIndex;
              const showResult = mode === 'practice' && selectedOptions[currentQuestionIndex] !== undefined;

              return (
                <button
                  key={idx}
                  disabled={selectedOptions[currentQuestionIndex] !== undefined && mode === 'practice'}
                  onClick={() => handleOptionSelect(idx)}
                  className={cn(
                    "w-full text-left p-4 rounded-xl border-2 transition-all flex items-center justify-between group",
                    isSelected && !showResult && "border-sky-400 bg-sky-500/10",
                    showResult && isCorrect && "border-cyan-400 bg-cyan-500/10",
                    showResult && isSelected && !isCorrect && "border-red-400 bg-red-500/10",
                    !isSelected && !showResult && "border-sky-400/5 hover:border-sky-400/20"
                  )}
                >
                  <div className="flex items-center gap-4">
                    <span className={cn(
                      "h-8 w-8 rounded-lg flex items-center justify-center text-sm font-bold transition-colors",
                      isSelected && !showResult && "bg-sky-400 text-white",
                      showResult && isCorrect && "bg-cyan-400 text-white",
                      showResult && isSelected && !isCorrect && "bg-red-400 text-white",
                      !isSelected && !showResult && "bg-sky-400/5 text-sky-300/40 group-hover:bg-sky-400/10"
                    )}>
                      {String.fromCharCode(65 + idx)}
                    </span>
                    <span className={cn(
                      "text-sm font-medium",
                      isSelected && !showResult && "text-sky-300",
                      showResult && isCorrect && "text-cyan-300",
                      showResult && isSelected && !isCorrect && "text-red-300",
                      !isSelected && !showResult && "text-sky-200/60"
                    )}>
                      {option}
                    </span>
                  </div>
                  {showResult && isCorrect && <CheckCircle2 className="h-5 w-5 text-cyan-400" />}
                  {showResult && isSelected && !isCorrect && <XCircle className="h-5 w-5 text-red-400" />}
                </button>
              );
            })}
          </div>

          {showExplanation && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-8 p-6 bg-sky-500/10 rounded-xl border-l-4 border-sky-400"
            >
              <div className="flex items-center gap-2 text-sky-300 font-bold mb-2">
                <HelpCircle className="h-5 w-5" />
                Giải thích pháp lý
              </div>
              <p className="text-sm text-sky-200/60 leading-relaxed">
                {currentQuestion.explanation}
              </p>
            </motion.div>
          )}

          <div className="mt-10 flex justify-between items-center">
            <button
              onClick={() => setCurrentQuestionIndex(prev => Math.max(0, prev - 1))}
              disabled={currentQuestionIndex === 0}
              className="flex items-center gap-2 px-4 py-2 text-sky-300/40 disabled:opacity-30"
            >
              <ArrowLeft className="h-4 w-4" />
              Câu trước
            </button>
            <button
              onClick={handleNext}
              disabled={selectedOptions[currentQuestionIndex] === undefined}
              className="flex items-center gap-2 px-8 py-3 bg-sky-600 text-white rounded-xl font-bold hover:bg-sky-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-sky-600/20"
            >
              {currentQuestionIndex === quizQuestions.length - 1 ? 'Hoàn thành' : 'Tiếp theo'}
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

export default QuizPage;
