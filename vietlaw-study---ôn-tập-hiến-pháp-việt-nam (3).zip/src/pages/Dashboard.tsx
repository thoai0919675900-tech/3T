import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie
} from 'recharts';
import { 
  BookOpen, 
  CheckCircle, 
  Clock, 
  TrendingUp, 
  Award,
  ArrowRight,
  CheckSquare,
  AlertCircle,
  Sparkles,
  Zap,
  Brain,
  Bot,
  MessageSquare,
  Gavel,
  History
} from 'lucide-react';
import { useProgress } from '../context/ProgressContext';
import { chapters } from '../data/mockData';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { formatDate, cn } from '../utils/utils';

const Dashboard: React.FC = () => {
  const { results, progress } = useProgress();

  const totalQuizzes = results.length;
  const avgScore = totalQuizzes > 0 
    ? Math.round((results.reduce((acc, curr) => acc + (curr.score / curr.totalQuestions), 0) / totalQuizzes) * 100) 
    : 0;
  
  const completedChaptersCount = progress?.completedChapters.length || 0;
  const masteredFlashcardsCount = progress?.masteredFlashcards.length || 0;

  const chartData = chapters.map(ch => {
    const chapterResults = results.filter(r => r.chapterId === ch.id);
    const avg = chapterResults.length > 0
      ? Math.round((chapterResults.reduce((acc, curr) => acc + (curr.score / curr.totalQuestions), 0) / chapterResults.length) * 100)
      : 0;
    return {
      name: ch.title.split(':')[0],
      score: avg
    };
  });

  const completionData = [
    { name: 'Hoàn thành', value: completedChaptersCount },
    { name: 'Chưa học', value: chapters.length - completedChaptersCount }
  ];

  const COLORS = ['#0ea5e9', 'rgba(255, 255, 255, 0.05)'];

  const stats = [
    { name: 'Tổng bài làm', value: totalQuizzes, icon: Clock, color: 'text-sky-400', bg: 'bg-sky-500/10' },
    { name: 'Điểm trung bình', value: `${avgScore}%`, icon: TrendingUp, color: 'text-cyan-400', bg: 'bg-cyan-500/10' },
    { name: 'Chương hoàn thành', value: `${completedChaptersCount}/${chapters.length}`, icon: CheckCircle, color: 'text-blue-400', bg: 'bg-blue-500/10' },
    { name: 'Thẻ ghi nhớ đã thuộc', value: masteredFlashcardsCount, icon: Award, color: 'text-sky-400', bg: 'bg-sky-500/10' },
  ];

  return (
    <div className="space-y-10 pb-20">
      <header className="relative py-12 px-8 rounded-[32px] overflow-hidden bg-sky-950/20 border border-sky-400/10 shadow-2xl">
        <div className="absolute inset-0 bg-gradient-to-br from-sky-600/20 to-transparent pointer-events-none" />
        <div className="absolute top-0 right-0 w-1/2 h-full bg-[url('https://picsum.photos/seed/legal/800/800')] opacity-10 mix-blend-overlay grayscale" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <h1 className="text-4xl md:text-5xl font-black text-white tracking-tight">
              Trung tâm <span className="text-sky-400">Điều khiển</span>
            </h1>
            <p className="text-sky-200/60 mt-2 text-lg max-w-md">
              Theo dõi hành trình chinh phục Hiến pháp, Hình sự, Dân sự và Doanh nghiệp Việt Nam của bạn.
            </p>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex items-center gap-4"
          >
            <Link 
              to="/quiz" 
              className="px-8 py-4 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-2xl shadow-xl shadow-sky-600/20 transition-all active:scale-95 flex items-center gap-2"
            >
              <CheckSquare className="h-5 w-5" />
              Luyện tập ngay
            </Link>
          </motion.div>
        </div>
      </header>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, idx) => (
          <motion.div
            key={stat.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="bg-zinc-900/50 backdrop-blur-xl p-6 rounded-3xl border border-white/5 shadow-xl group hover:border-white/10 transition-all"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-bold text-zinc-500 uppercase tracking-wider">{stat.name}</p>
                <p className="text-3xl font-black text-white mt-2">{stat.value}</p>
              </div>
              <div className={cn("p-4 rounded-2xl transition-transform group-hover:scale-110", stat.bg)}>
                <stat.icon className={cn("h-7 w-7", stat.color)} />
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Daily Challenge Card */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="lg:col-span-2 relative overflow-hidden glass-dark p-8 rounded-[40px] border border-sky-500/20 shadow-2xl group"
        >
          <div className="absolute top-0 right-0 w-64 h-64 bg-sky-600/10 blur-[100px] -mr-32 -mt-32 pointer-events-none" />
          <div className="relative z-10 flex flex-col md:flex-row items-center gap-8">
            <div className="p-6 bg-sky-600 rounded-[32px] shadow-2xl shadow-sky-600/40 group-hover:scale-110 transition-transform duration-500">
              <Zap className="h-12 w-12 text-white" />
            </div>
            <div className="flex-1 text-center md:text-left">
              <div className="flex items-center justify-center md:justify-start gap-3 mb-2">
                <span className="px-3 py-1 bg-sky-500/10 text-sky-400 text-[10px] font-black uppercase tracking-widest rounded-full border border-sky-500/20">Thử thách hàng ngày</span>
                <span className="flex items-center gap-1 text-cyan-400 text-[10px] font-black uppercase tracking-widest">
                  <Sparkles className="h-3 w-3" />
                  +500 Điểm
                </span>
              </div>
              <h3 className="text-2xl font-black text-white tracking-tight">Câu hỏi của ngày hôm nay</h3>
              <p className="text-sky-100/60 mt-2 leading-relaxed max-w-md">
                "Theo Hiến pháp 2013, cơ quan nào là cơ quan đại biểu cao nhất của Nhân dân?"
              </p>
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 mt-6">
                <button className="px-6 py-3 bg-white text-zinc-950 font-black text-xs uppercase tracking-widest rounded-2xl hover:bg-sky-500 hover:text-white transition-all active:scale-95">Trả lời ngay</button>
                <p className="text-xs font-bold text-sky-500/60 flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  Còn lại 14:25:00
                </p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* AI Assistant Quick Access */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass-dark p-8 rounded-[40px] border border-white/5 shadow-2xl flex flex-col justify-between group hover:border-sky-500/30 transition-all"
        >
          <div>
            <div className="flex items-center justify-between mb-6">
              <div className="p-4 bg-zinc-800 rounded-2xl text-sky-400 group-hover:bg-sky-600 group-hover:text-white transition-all">
                <Bot className="h-6 w-6" />
              </div>
              <span className="px-2 py-1 bg-emerald-500/10 text-emerald-500 text-[8px] font-black uppercase tracking-widest rounded-md border border-emerald-500/20">Trực tuyến</span>
            </div>
            <h3 className="text-xl font-black text-white">VietLaw AI</h3>
            <p className="text-sky-100/60 text-sm mt-2 leading-relaxed">
              Bạn có thắc mắc về Điều 15 hay quyền con người? Hãy hỏi trợ lý AI của chúng tôi ngay.
            </p>
          </div>
          <Link to="/ai-assistant" className="mt-8 flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/10 transition-all group/btn">
            <span className="text-sm font-bold text-white">Bắt đầu trò chuyện</span>
            <ArrowRight className="h-5 w-5 text-sky-500/60 group-hover/btn:translate-x-1 transition-transform" />
          </Link>
        </motion.div>

        {/* Mock Trial Quick Access */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="glass-dark p-8 rounded-[40px] border border-white/5 shadow-2xl flex flex-col justify-between group hover:border-cyan-500/30 transition-all"
        >
          <div>
            <div className="flex items-center justify-between mb-6">
              <div className="p-4 bg-zinc-800 rounded-2xl text-cyan-500 group-hover:bg-cyan-600 group-hover:text-white transition-all">
                <Gavel className="h-6 w-6" />
              </div>
              <span className="px-2 py-1 bg-cyan-500/10 text-cyan-500 text-[8px] font-black uppercase tracking-widest rounded-md border border-cyan-500/20">Mới</span>
            </div>
            <h3 className="text-xl font-black text-white">Phiên tòa giả định</h3>
            <p className="text-sky-100/60 text-sm mt-2 leading-relaxed">
              Bạn có đủ tự tin để tranh tụng trước Hội đồng xét xử AI? Hãy thử sức ngay.
            </p>
          </div>
          <Link to="/mock-trial" className="mt-8 flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/10 transition-all group/btn">
            <span className="text-sm font-bold text-white">Tham gia tranh tụng</span>
            <ArrowRight className="h-5 w-5 text-sky-500/60 group-hover/btn:translate-x-1 transition-transform" />
          </Link>
        </motion.div>

        {/* Timeline Quick Access */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="glass-dark p-8 rounded-[40px] border border-white/5 shadow-2xl flex flex-col justify-between group hover:border-sky-400/30 transition-all"
        >
          <div>
            <div className="flex items-center justify-between mb-6">
              <div className="p-4 bg-zinc-800 rounded-2xl text-sky-400 group-hover:bg-sky-500 group-hover:text-white transition-all">
                <History className="h-6 w-6" />
              </div>
            </div>
            <h3 className="text-xl font-black text-white">Lịch sử Hiến pháp</h3>
            <p className="text-sky-100/60 text-sm mt-2 leading-relaxed">
              Khám phá hành trình 77 năm phát triển của các bản Hiến pháp Việt Nam.
            </p>
          </div>
          <Link to="/timeline" className="mt-8 flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/10 transition-all group/btn">
            <span className="text-sm font-bold text-white">Khám phá ngay</span>
            <ArrowRight className="h-5 w-5 text-sky-500/60 group-hover/btn:translate-x-1 transition-transform" />
          </Link>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-sky-950/20 backdrop-blur-xl p-8 rounded-[32px] border border-sky-400/10 shadow-xl">
          <div className="flex items-center justify-between mb-10">
            <h3 className="text-xl font-bold text-white flex items-center gap-3">
              <TrendingUp className="h-6 w-6 text-sky-400" />
              Hiệu suất theo chương
            </h3>
          </div>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(56,189,248,0.05)" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#7dd3fc', fontSize: 12, fontWeight: 600 }} 
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#7dd3fc', fontSize: 12 }} 
                  domain={[0, 100]} 
                />
                <Tooltip 
                  cursor={{ fill: 'rgba(56,189,248,0.02)' }}
                  contentStyle={{ 
                    backgroundColor: '#0c4a6e', 
                    borderRadius: '16px', 
                    border: '1px solid rgba(56,189,248,0.1)',
                    boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.5)' 
                  }}
                  itemStyle={{ color: '#fff', fontWeight: 700 }}
                />
                <Bar dataKey="score" radius={[8, 8, 0, 0]} barSize={40}>
                  {chartData.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={entry.score > 80 ? '#06b6d4' : entry.score > 50 ? '#0ea5e9' : '#f43f5e'} 
                      fillOpacity={0.8}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-sky-950/20 backdrop-blur-xl p-8 rounded-[32px] border border-sky-400/10 shadow-xl flex flex-col">
          <h3 className="text-xl font-bold text-white mb-10 flex items-center gap-3">
            <CheckCircle className="h-6 w-6 text-sky-400" />
            Tiến độ tổng quát
          </h3>
          <div className="flex-1 flex items-center justify-center relative">
            <div className="absolute inset-0 flex flex-col items-center justify-center z-10">
              <span className="text-4xl font-black text-white">{Math.round((completedChaptersCount / chapters.length) * 100)}%</span>
              <span className="text-xs font-bold text-sky-300/50 uppercase tracking-widest mt-1">Hoàn thành</span>
            </div>
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie
                  data={completionData}
                  cx="50%"
                  cy="50%"
                  innerRadius={80}
                  outerRadius={100}
                  paddingAngle={8}
                  dataKey="value"
                  stroke="none"
                >
                  {completionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-8 space-y-4">
            <div className="flex items-center justify-between p-4 bg-sky-400/5 rounded-2xl border border-sky-400/10">
              <span className="text-sky-200/60 font-medium">Đã hoàn thành</span>
              <span className="font-black text-sky-400">{completedChaptersCount} / {chapters.length}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-sky-950/20 backdrop-blur-xl rounded-[32px] border border-sky-400/10 shadow-xl overflow-hidden">
        <div className="p-8 border-b border-sky-400/10 flex items-center justify-between">
          <h3 className="text-xl font-bold text-white flex items-center gap-3">
            <Clock className="h-6 w-6 text-sky-400" />
            Hoạt động gần đây
          </h3>
          <Link to="/quiz" className="px-4 py-2 bg-sky-400/10 hover:bg-sky-400/20 rounded-xl text-sm font-bold text-sky-200 transition-all flex items-center gap-2">
            Xem tất cả <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-sky-400/5 text-sky-300/50 text-xs font-black uppercase tracking-[0.2em]">
              <tr>
                <th className="px-8 py-5">Chương</th>
                <th className="px-8 py-5">Chế độ</th>
                <th className="px-8 py-5">Kết quả</th>
                <th className="px-8 py-5">Ngày thực hiện</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-sky-400/10">
              {results.length > 0 ? (
                results.slice(0, 5).map((result) => (
                  <tr key={result.id} className="hover:bg-sky-400/5 transition-colors group">
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-3">
                        <div className="w-2 h-2 rounded-full bg-sky-500" />
                        <span className="font-bold text-white">{chapters.find(c => c.id === result.chapterId)?.title.split(':')[0]}</span>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <span className={cn(
                        "px-3 py-1 rounded-lg text-xs font-black uppercase tracking-wider",
                        result.type === 'practice' ? "bg-sky-500/10 text-sky-400" : "bg-cyan-500/10 text-cyan-400"
                      )}>
                        {result.type === 'practice' ? 'Luyện tập' : 'Thi thử'}
                      </span>
                    </td>
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-2">
                        <span className="text-xl font-black text-white">{result.score}</span>
                        <span className="text-sky-300/50 font-bold">/ {result.totalQuestions}</span>
                      </div>
                    </td>
                    <td className="px-8 py-6 text-sm text-sky-300/40 font-medium">
                      {formatDate(result.date)}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="px-8 py-20 text-center">
                    <div className="flex flex-col items-center gap-4">
                      <div className="p-4 bg-sky-400/5 rounded-full">
                        <AlertCircle className="h-8 w-8 text-sky-900" />
                      </div>
                      <p className="text-sky-300/40 font-medium">Chưa có dữ liệu hoạt động.</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
