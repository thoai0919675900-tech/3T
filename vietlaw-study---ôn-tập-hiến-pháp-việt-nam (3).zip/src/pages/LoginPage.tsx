import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BookOpen, User, ShieldCheck, ArrowRight, TrendingUp } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../types';
import { motion } from 'motion/react';

const LoginPage: React.FC = () => {
  const [username, setUsername] = useState('');
  const [role, setRole] = useState<UserRole>(UserRole.STUDENT);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim()) {
      login(username, role);
      navigate('/');
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] flex items-center justify-center p-4 overflow-hidden relative">
      {/* Immersive Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-sky-600/20 blur-[120px] rounded-full animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-cyan-600/10 blur-[120px] rounded-full" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-[0.03]" />
      </div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="max-w-4xl w-full grid grid-cols-1 lg:grid-cols-2 bg-sky-950/20 backdrop-blur-2xl rounded-[32px] shadow-2xl border border-sky-400/10 overflow-hidden relative z-10"
      >
        {/* Left Side - Brand/Hero */}
        <div className="p-12 bg-gradient-to-br from-sky-600 to-cyan-700 flex flex-col justify-between relative overflow-hidden">
          <div className="absolute inset-0 bg-[url('https://picsum.photos/seed/justice/1000/1000')] opacity-20 mix-blend-overlay" />
          <div className="relative z-10">
            <div className="inline-flex items-center justify-center p-3 bg-white/20 backdrop-blur-md rounded-2xl mb-8">
              <BookOpen className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-5xl font-black text-white tracking-tight leading-tight">
              VietLaw <br /> Study
            </h1>
            <p className="text-sky-100/80 mt-4 text-lg font-medium max-w-xs">
              Nâng tầm kiến thức Hiến pháp Việt Nam với trải nghiệm học tập hiện đại.
            </p>
          </div>
          
          <div className="relative z-10 space-y-4">
            <div className="flex items-center gap-3 text-sky-100/60 text-sm">
              <ShieldCheck className="h-5 w-5" />
              <span>Dữ liệu chuẩn Hiến pháp 2013</span>
            </div>
            <div className="flex items-center gap-3 text-sky-100/60 text-sm">
              <TrendingUp className="h-5 w-5" />
              <span>Theo dõi tiến độ thời gian thực</span>
            </div>
          </div>
        </div>

        {/* Right Side - Form */}
        <div className="p-12 flex flex-col justify-center">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-white">Chào mừng bạn</h2>
            <p className="text-sky-200/60 mt-1">Đăng nhập để bắt đầu hành trình ôn tập.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-semibold text-sky-300/40 mb-2 uppercase tracking-wider">
                Tên đăng nhập
              </label>
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <User className="h-5 w-5 text-sky-300/20 group-focus-within:text-sky-400 transition-colors" />
                </div>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="block w-full pl-12 pr-4 py-4 bg-sky-400/5 border border-sky-400/10 rounded-2xl text-white placeholder-sky-300/20 focus:outline-none focus:ring-2 focus:ring-sky-400/50 focus:bg-sky-400/10 transition-all"
                  placeholder="Nhập tên của bạn..."
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-sky-300/40 mb-2 uppercase tracking-wider">
                Vai trò người dùng
              </label>
              <div className="grid grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => setRole(UserRole.STUDENT)}
                  className={`flex items-center justify-center gap-3 p-4 rounded-2xl border-2 transition-all duration-300 ${
                    role === UserRole.STUDENT
                      ? 'border-sky-400 bg-sky-500/10 text-sky-400 shadow-[0_0_20px_rgba(56,189,248,0.2)]'
                      : 'border-sky-400/5 bg-sky-400/5 text-sky-300/40 hover:border-sky-400/10 hover:bg-sky-400/10'
                  }`}
                >
                  <User className="h-5 w-5" />
                  <span className="font-bold">Sinh viên</span>
                </button>
                <button
                  type="button"
                  onClick={() => setRole(UserRole.ADMIN)}
                  className={`flex items-center justify-center gap-3 p-4 rounded-2xl border-2 transition-all duration-300 ${
                    role === UserRole.ADMIN
                      ? 'border-sky-400 bg-sky-500/10 text-sky-400 shadow-[0_0_20px_rgba(56,189,248,0.2)]'
                      : 'border-sky-400/5 bg-sky-400/5 text-sky-300/40 hover:border-sky-400/10 hover:bg-sky-400/10'
                  }`}
                >
                  <ShieldCheck className="h-5 w-5" />
                  <span className="font-bold">Quản trị</span>
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-sky-600 hover:bg-sky-500 text-white font-bold py-4 rounded-2xl shadow-xl shadow-sky-600/30 flex items-center justify-center gap-3 transition-all active:scale-[0.98] group"
            >
              <span>Bắt đầu ngay</span>
              <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </form>

          <p className="mt-8 text-center text-xs text-sky-300/20 font-medium">
            VIETLAW STUDY v2.0 • TRẢI NGHIỆM HỌC TẬP CAO CẤP
          </p>
        </div>
      </motion.div>
    </div>
  );
};

export default LoginPage;
