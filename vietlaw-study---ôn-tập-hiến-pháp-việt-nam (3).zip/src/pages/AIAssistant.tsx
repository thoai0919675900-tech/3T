import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { 
  Send, 
  Bot, 
  User as UserIcon, 
  Sparkles, 
  MessageSquare, 
  Trash2,
  Scale,
  ShieldCheck,
  Info
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ChatMessage } from '../types';
import { cn } from '../utils/utils';

const AIAssistant: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Xin chào! Tôi là Trợ lý Luật VietLaw. Tôi có thể giúp bạn giải thích các điều khoản trong Hiến pháp 2013, Luật Doanh nghiệp 2020, Bộ luật Hình sự 2015, Bộ luật Dân sự 2015 hoặc trả lời các câu hỏi liên quan đến pháp luật Việt Nam. Bạn muốn tìm hiểu về nội dung nào?',
      timestamp: new Date().toISOString(),
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date().toISOString(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      const model = "gemini-3-flash-preview";
      
      const systemInstruction = `Bạn là một chuyên gia về hệ thống pháp luật Việt Nam, bao gồm: Hiến pháp 2013, Luật Doanh nghiệp 2020, Bộ luật Hình sự 2015 và Bộ luật Dân sự 2015. 
      Nhiệm vụ của bạn là giải thích các điều luật một cách dễ hiểu, chính xác và khách quan cho sinh viên.
      Hãy luôn trích dẫn các Điều trong các bộ luật liên quan nếu có thể. 
      Nếu câu hỏi không liên quan đến pháp luật, hãy lịch sự nhắc nhở người dùng rằng bạn chuyên về lĩnh vực này.
      Trả lời bằng tiếng Việt, phong cách chuyên nghiệp nhưng gần gũi.`;

      const response = await ai.models.generateContent({
        model: model,
        contents: [
          { role: 'user', parts: [{ text: input }] }
        ],
        config: {
          systemInstruction: systemInstruction,
        }
      });

      const assistantMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.text || 'Xin lỗi, tôi không thể trả lời câu hỏi này lúc này.',
        timestamp: new Date().toISOString(),
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('AI Error:', error);
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'Đã có lỗi xảy ra khi kết nối với máy chủ AI. Vui lòng thử lại sau.',
        timestamp: new Date().toISOString(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const clearChat = () => {
    setMessages([messages[0]]);
  };

  return (
    <div className="max-w-5xl mx-auto h-[calc(100vh-180px)] flex flex-col gap-6">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-sky-600 rounded-2xl shadow-lg shadow-sky-600/20">
            <Bot className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-black text-white tracking-tight">Trợ lý <span className="text-gradient">AI VietLaw</span></h1>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse" />
              <p className="text-xs font-bold text-sky-300/40 uppercase tracking-widest">Trực tuyến • Hiến pháp & Đa ngành luật</p>
            </div>
          </div>
        </div>
        <button 
          onClick={clearChat}
          className="p-3 bg-white/5 hover:bg-red-500/10 text-zinc-500 hover:text-red-500 rounded-2xl transition-all border border-white/5"
          title="Xóa hội thoại"
        >
          <Trash2 className="h-5 w-5" />
        </button>
      </header>

      <div className="flex-1 glass-dark rounded-[32px] border border-white/5 shadow-2xl flex flex-col overflow-hidden relative">
        {/* Chat Background Pattern */}
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-5 pointer-events-none" />
        
        <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar relative z-10">
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn(
                "flex gap-4 max-w-[85%]",
                msg.role === 'user' ? "ml-auto flex-row-reverse" : "mr-auto"
              )}
            >
              <div className={cn(
                "w-10 h-10 rounded-xl flex items-center justify-center shrink-0 shadow-lg",
                msg.role === 'user' ? "bg-sky-900/50 text-white" : "bg-sky-600 text-white"
              )}>
                {msg.role === 'user' ? <UserIcon className="h-5 w-5" /> : <Bot className="h-5 w-5" />}
              </div>
              <div className={cn(
                "p-4 rounded-2xl text-sm leading-relaxed shadow-sm",
                msg.role === 'user' 
                  ? "bg-sky-950/50 text-sky-100 rounded-tr-none border border-sky-400/10" 
                  : "bg-sky-400/5 text-sky-100 rounded-tl-none border border-sky-400/10 backdrop-blur-sm"
              )}>
                {msg.content}
                <p className="text-[10px] mt-2 opacity-30 font-bold uppercase tracking-widest">
                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </motion.div>
          ))}
          {isLoading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex gap-4 mr-auto"
            >
              <div className="w-10 h-10 rounded-xl bg-sky-600 flex items-center justify-center shadow-lg">
                <Bot className="h-5 w-5 text-white" />
              </div>
              <div className="p-4 bg-sky-400/5 rounded-2xl rounded-tl-none border border-sky-400/10 flex gap-1">
                <span className="w-1.5 h-1.5 bg-sky-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1.5 h-1.5 bg-sky-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1.5 h-1.5 bg-sky-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </motion.div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="p-6 bg-sky-400/5 border-t border-sky-400/10 relative z-10">
          <div className="flex gap-4">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Hỏi về Hiến pháp, Hình sự, Dân sự hoặc Doanh nghiệp..."
              className="flex-1 bg-sky-950/50 border border-sky-400/10 rounded-2xl px-6 py-4 text-white placeholder:text-sky-300/20 focus:outline-none focus:border-sky-400/50 transition-all"
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              className="p-4 bg-sky-600 hover:bg-sky-500 disabled:opacity-50 disabled:hover:bg-sky-600 text-white rounded-2xl shadow-lg shadow-sky-600/20 transition-all active:scale-95"
            >
              <Send className="h-6 w-6" />
            </button>
          </div>
          <div className="flex items-center gap-6 mt-4 px-2">
            <div className="flex items-center gap-2 text-[10px] font-black text-sky-300/40 uppercase tracking-widest">
              <Scale className="h-3 w-3" />
              <span>Pháp lý chuẩn xác</span>
            </div>
            <div className="flex items-center gap-2 text-[10px] font-black text-sky-300/40 uppercase tracking-widest">
              <ShieldCheck className="h-3 w-3" />
              <span>Bảo mật thông tin</span>
            </div>
            <div className="flex items-center gap-2 text-[10px] font-black text-sky-300/40 uppercase tracking-widest ml-auto">
              <Sparkles className="h-3 w-3 text-sky-400" />
              <span>Cung cấp bởi Gemini AI</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[
          { icon: MessageSquare, title: 'Giải thích Điều luật', desc: 'Phân tích ý nghĩa các điều khoản Hiến pháp.' },
          { icon: Scale, title: 'Tư vấn Học tập', desc: 'Hỗ trợ giải đáp các chuyên đề luật khó.' },
          { icon: Info, title: 'Tra cứu nhanh', desc: 'Tìm kiếm thông tin pháp luật tức thì.' }
        ].map((item, i) => (
          <div key={i} className="glass-dark p-4 rounded-2xl border border-sky-400/10 flex items-center gap-4">
            <div className="p-2 bg-sky-400/5 rounded-xl text-sky-400">
              <item.icon className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-white">{item.title}</p>
              <p className="text-[10px] text-sky-300/40">{item.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AIAssistant;
