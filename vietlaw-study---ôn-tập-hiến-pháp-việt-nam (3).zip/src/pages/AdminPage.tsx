import React, { useState } from 'react';
import { 
  Plus, 
  Search, 
  Edit2, 
  Trash2, 
  FileJson, 
  Download, 
  Upload,
  BookOpen,
  CheckSquare,
  CreditCard,
  AlertCircle
} from 'lucide-react';
import { chapters, questions, flashcards } from '../data/mockData';
import { motion } from 'motion/react';
import { cn } from '../utils/utils';

const AdminPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'chapters' | 'questions' | 'flashcards'>('chapters');
  const [searchTerm, setSearchTerm] = useState('');

  const tabs = [
    { id: 'chapters', name: 'Chuyên đề', icon: BookOpen },
    { id: 'questions', name: 'Câu hỏi', icon: CheckSquare },
    { id: 'flashcards', name: 'Thẻ ghi nhớ', icon: CreditCard },
  ];

  const handleExport = () => {
    const data = { chapters, questions, flashcards };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'vietlaw_data.json';
    a.click();
  };

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white">Quản trị hệ thống</h1>
          <p className="text-sky-300/40 mt-1">Quản lý nội dung chuyên đề, câu hỏi và flashcards.</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={handleExport}
            className="flex items-center gap-2 px-4 py-2 bg-sky-950/20 border border-sky-400/10 rounded-xl text-sm font-medium hover:bg-sky-400/5 transition-all text-white"
          >
            <Download className="h-4 w-4" />
            Xuất JSON
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-sky-600 text-white rounded-xl text-sm font-medium hover:bg-sky-500 transition-all shadow-lg shadow-sky-600/20">
            <Plus className="h-4 w-4" />
            Thêm mới
          </button>
        </div>
      </header>

      <div className="flex border-b border-sky-400/10">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={cn(
              "px-6 py-4 text-sm font-medium border-b-2 transition-all flex items-center gap-2",
              activeTab === tab.id
                ? "border-sky-400 text-sky-400"
                : "border-transparent text-sky-300/40 hover:text-white"
            )}
          >
            <tab.icon className="h-4 w-4" />
            {tab.name}
          </button>
        ))}
      </div>

      <div className="bg-sky-950/20 rounded-2xl border border-sky-400/10 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-sky-400/10 flex items-center gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-sky-300/20" />
            <input
              type="text"
              placeholder={`Tìm kiếm ${tabs.find(t => t.id === activeTab)?.name.toLowerCase()}...`}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-sky-400/5 border-none rounded-lg text-sm text-white focus:ring-2 focus:ring-sky-400/50"
            />
          </div>
          <div className="flex items-center gap-2 text-xs text-sky-300/40">
            <AlertCircle className="h-4 w-4" />
            <span>Chế độ xem (Quản trị thử nghiệm)</span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-sky-400/5 text-sky-300/40 text-xs uppercase tracking-wider">
              {activeTab === 'chapters' && (
                <tr>
                  <th className="px-6 py-4 font-medium">ID</th>
                  <th className="px-6 py-4 font-medium">Tiêu đề</th>
                  <th className="px-6 py-4 font-medium">Mô tả</th>
                  <th className="px-6 py-4 font-medium text-right">Thao tác</th>
                </tr>
              )}
              {activeTab === 'questions' && (
                <tr>
                  <th className="px-6 py-4 font-medium">ID</th>
                  <th className="px-6 py-4 font-medium">Nội dung câu hỏi</th>
                  <th className="px-6 py-4 font-medium">Chương</th>
                  <th className="px-6 py-4 font-medium text-right">Thao tác</th>
                </tr>
              )}
              {activeTab === 'flashcards' && (
                <tr>
                  <th className="px-6 py-4 font-medium">ID</th>
                  <th className="px-6 py-4 font-medium">Điều luật</th>
                  <th className="px-6 py-4 font-medium">Nội dung</th>
                  <th className="px-6 py-4 font-medium text-right">Thao tác</th>
                </tr>
              )}
            </thead>
            <tbody className="divide-y divide-sky-400/10">
              {activeTab === 'chapters' && chapters.map((ch) => (
                <tr key={ch.id} className="hover:bg-sky-400/5 transition-colors">
                  <td className="px-6 py-4 text-sm font-mono text-sky-300/40">{ch.id}</td>
                  <td className="px-6 py-4 text-sm font-medium text-white">{ch.title}</td>
                  <td className="px-6 py-4 text-sm text-sky-200/60 truncate max-w-xs">{ch.description}</td>
                  <td className="px-6 py-4 text-right space-x-2">
                    <button className="p-2 text-sky-300/20 hover:text-sky-400 transition-colors"><Edit2 className="h-4 w-4" /></button>
                    <button className="p-2 text-sky-300/20 hover:text-red-400 transition-colors"><Trash2 className="h-4 w-4" /></button>
                  </td>
                </tr>
              ))}
              {activeTab === 'questions' && questions.map((q) => (
                <tr key={q.id} className="hover:bg-sky-400/5 transition-colors">
                  <td className="px-6 py-4 text-sm font-mono text-sky-300/40">{q.id}</td>
                  <td className="px-6 py-4 text-sm text-white truncate max-w-md">{q.questionText}</td>
                  <td className="px-6 py-4 text-sm text-sky-200/60">{chapters.find(c => c.id === q.chapterId)?.title.split(':')[0]}</td>
                  <td className="px-6 py-4 text-right space-x-2">
                    <button className="p-2 text-sky-300/20 hover:text-sky-400 transition-colors"><Edit2 className="h-4 w-4" /></button>
                    <button className="p-2 text-sky-300/20 hover:text-red-400 transition-colors"><Trash2 className="h-4 w-4" /></button>
                  </td>
                </tr>
              ))}
              {activeTab === 'flashcards' && flashcards.map((f) => (
                <tr key={f.id} className="hover:bg-sky-400/5 transition-colors">
                  <td className="px-6 py-4 text-sm font-mono text-sky-300/40">{f.id}</td>
                  <td className="px-6 py-4 text-sm font-bold text-sky-400">{f.articleNumber}</td>
                  <td className="px-6 py-4 text-sm text-sky-200/60 truncate max-w-md">{f.content}</td>
                  <td className="px-6 py-4 text-right space-x-2">
                    <button className="p-2 text-sky-300/20 hover:text-sky-400 transition-colors"><Edit2 className="h-4 w-4" /></button>
                    <button className="p-2 text-sky-300/20 hover:text-red-400 transition-colors"><Trash2 className="h-4 w-4" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminPage;
