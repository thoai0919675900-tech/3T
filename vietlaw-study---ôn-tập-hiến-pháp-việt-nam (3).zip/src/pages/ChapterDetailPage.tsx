import React from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, BookOpen, CheckSquare, CreditCard, Search } from 'lucide-react';
import { chapters, flashcards } from '../data/mockData';
import { motion } from 'motion/react';

const ChapterDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const chapter = chapters.find(c => c.id === id);

  if (!chapter) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold">Không tìm thấy chuyên đề</h2>
        <Link to="/chapters" className="text-blue-600 mt-4 inline-block">Quay lại danh sách</Link>
      </div>
    );
  }

  const chapterFlashcards = flashcards.filter(f => f.chapterId === id);

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <button 
        onClick={() => navigate('/chapters')}
        className="flex items-center gap-2 text-sky-300/40 hover:text-white transition-colors"
      >
        <ArrowLeft className="h-4 w-4" />
        Quay lại
      </button>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-sky-950/20 rounded-2xl border border-sky-400/10 p-8 shadow-sm"
      >
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 rounded-xl bg-sky-600 text-white">
            <BookOpen className="h-6 w-6" />
          </div>
          <h1 className="text-3xl font-bold text-white">{chapter.title}</h1>
        </div>

        <div className="prose prose-zinc dark:prose-invert max-w-none">
          <div className="bg-sky-400/5 p-6 rounded-xl mb-8 border-l-4 border-sky-400">
            <h3 className="text-lg font-semibold mb-2 flex items-center gap-2 text-white">
              <Search className="h-5 w-5 text-sky-400" />
              Tóm tắt nội dung
            </h3>
            <p className="text-sky-200/60 leading-relaxed">
              {chapter.content}
            </p>
          </div>

          <h3 className="text-xl font-bold mb-4 text-white">Các điều khoản trọng tâm</h3>
          <div className="grid grid-cols-1 gap-4">
            {chapterFlashcards.map((card) => (
              <div key={card.id} className="p-4 bg-sky-900/50 rounded-xl border border-sky-400/10">
                <span className="inline-block px-2 py-1 bg-sky-500/10 text-sky-300 text-xs font-bold rounded mb-2">
                  {card.articleNumber}
                </span>
                <p className="text-sky-100 text-sm">
                  {card.content}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-12 pt-8 border-t border-sky-400/10">
          <Link 
            to={`/quiz?chapter=${chapter.id}`}
            className="flex items-center justify-center gap-3 p-4 bg-sky-600 hover:bg-sky-500 text-white rounded-xl font-semibold transition-all shadow-lg shadow-sky-600/20"
          >
            <CheckSquare className="h-5 w-5" />
            Làm trắc nghiệm ôn tập
          </Link>
          <Link 
            to={`/flashcards?chapter=${chapter.id}`}
            className="flex items-center justify-center gap-3 p-4 bg-sky-400/5 hover:bg-sky-400/10 text-white rounded-xl font-semibold transition-all"
          >
            <CreditCard className="h-5 w-5" />
            Học qua Flashcards
          </Link>
        </div>
      </motion.div>
    </div>
  );
};

export default ChapterDetailPage;
