import React from 'react';
import { 
  Trophy, 
  Medal, 
  Star, 
  TrendingUp, 
  Users, 
  Award,
  ChevronRight,
  Search
} from 'lucide-react';
import { motion } from 'motion/react';
import { LeaderboardEntry } from '../types';
import { cn } from '../utils/utils';

const mockLeaderboard: LeaderboardEntry[] = [
  { id: '1', userId: 'u1', fullName: 'Nguyễn Văn An', totalScore: 12500, quizzesTaken: 45, rank: 1, avatar: 'https://picsum.photos/seed/user1/100/100' },
  { id: '2', userId: 'u2', fullName: 'Trần Thị Bình', totalScore: 11800, quizzesTaken: 42, rank: 2, avatar: 'https://picsum.photos/seed/user2/100/100' },
  { id: '3', userId: 'u3', fullName: 'Lê Hoàng Nam', totalScore: 10200, quizzesTaken: 38, rank: 3, avatar: 'https://picsum.photos/seed/user3/100/100' },
  { id: '4', userId: 'u4', fullName: 'Phạm Minh Đức', totalScore: 9500, quizzesTaken: 35, rank: 4, avatar: 'https://picsum.photos/seed/user4/100/100' },
  { id: '5', userId: 'u5', fullName: 'Đặng Thu Hà', totalScore: 8900, quizzesTaken: 32, rank: 5, avatar: 'https://picsum.photos/seed/user5/100/100' },
  { id: '6', userId: 'u6', fullName: 'Vũ Hải Đăng', totalScore: 8200, quizzesTaken: 30, rank: 6, avatar: 'https://picsum.photos/seed/user6/100/100' },
  { id: '7', userId: 'u7', fullName: 'Bùi Tuyết Mai', totalScore: 7800, quizzesTaken: 28, rank: 7, avatar: 'https://picsum.photos/seed/user7/100/100' },
  { id: '8', userId: 'u8', fullName: 'Ngô Gia Bảo', totalScore: 7500, quizzesTaken: 25, rank: 8, avatar: 'https://picsum.photos/seed/user8/100/100' },
];

const Leaderboard: React.FC = () => {
  const topThree = mockLeaderboard.slice(0, 3);
  const others = mockLeaderboard.slice(3);

  return (
    <div className="max-w-5xl mx-auto space-y-12 pb-20">
      <header className="text-center space-y-4">
        <span className="px-4 py-1.5 bg-sky-500/10 text-sky-400 text-xs font-black uppercase tracking-[0.2em] rounded-full border border-sky-500/20">
          Vinh danh học viên
        </span>
        <h1 className="text-4xl md:text-5xl font-black text-white tracking-tight">
          Bảng <span className="text-gradient">Xếp Hạng</span>
        </h1>
        <p className="text-sky-200/40 max-w-lg mx-auto leading-relaxed">
          Nơi vinh danh những sinh viên xuất sắc nhất trong hành trình chinh phục Hiến pháp Việt Nam.
        </p>
      </header>

      {/* Podium */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-end max-w-4xl mx-auto px-4">
        {/* 2nd Place */}
        <motion.div 
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="order-2 md:order-1"
        >
          <div className="flex flex-col items-center gap-4 mb-4">
            <div className="relative">
              <img src={topThree[1].avatar} alt="" className="w-20 h-20 rounded-full border-4 border-zinc-400 shadow-2xl" referrerPolicy="no-referrer" />
              <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-zinc-400 rounded-full flex items-center justify-center text-zinc-950 font-black text-sm">2</div>
            </div>
            <div className="text-center">
              <p className="text-white font-bold">{topThree[1].fullName}</p>
              <p className="text-sky-400 font-black text-sm">{topThree[1].totalScore.toLocaleString()} điểm</p>
            </div>
          </div>
          <div className="h-32 glass-dark rounded-t-[32px] border border-white/5 flex items-center justify-center">
            <Medal className="h-10 w-10 text-zinc-400 opacity-20" />
          </div>
        </motion.div>

        {/* 1st Place */}
        <motion.div 
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          className="order-1 md:order-2"
        >
          <div className="flex flex-col items-center gap-6 mb-6">
            <div className="relative">
              <div className="absolute -top-8 left-1/2 -translate-x-1/2">
                <Trophy className="h-10 w-10 text-sky-400 animate-bounce" />
              </div>
              <img src={topThree[0].avatar} alt="" className="w-32 h-32 rounded-full border-4 border-sky-500 shadow-2xl shadow-sky-500/20" referrerPolicy="no-referrer" />
              <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-sky-500 rounded-full flex items-center justify-center text-zinc-950 font-black text-lg">1</div>
            </div>
            <div className="text-center">
              <p className="text-xl font-black text-white">{topThree[0].fullName}</p>
              <p className="text-sky-400 font-black text-lg">{topThree[0].totalScore.toLocaleString()} điểm</p>
            </div>
          </div>
          <div className="h-48 bg-gradient-to-b from-sky-500/20 to-sky-500/5 rounded-t-[40px] border border-sky-500/20 flex items-center justify-center">
            <Trophy className="h-16 w-16 text-sky-400 opacity-20" />
          </div>
        </motion.div>

        {/* 3rd Place */}
        <motion.div 
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="order-3"
        >
          <div className="flex flex-col items-center gap-4 mb-4">
            <div className="relative">
              <img src={topThree[2].avatar} alt="" className="w-20 h-20 rounded-full border-4 border-amber-800 shadow-2xl" referrerPolicy="no-referrer" />
              <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-amber-800 rounded-full flex items-center justify-center text-white font-black text-sm">3</div>
            </div>
            <div className="text-center">
              <p className="text-white font-bold">{topThree[2].fullName}</p>
              <p className="text-sky-400 font-black text-sm">{topThree[2].totalScore.toLocaleString()} điểm</p>
            </div>
          </div>
          <div className="h-24 glass-dark rounded-t-[32px] border border-white/5 flex items-center justify-center">
            <Award className="h-8 w-8 text-amber-800 opacity-20" />
          </div>
        </motion.div>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {[
          { icon: Users, label: 'Tổng học viên', value: '1,250', color: 'sky' },
          { icon: Star, label: 'Điểm trung bình', value: '8.5', color: 'cyan' },
          { icon: TrendingUp, label: 'Tăng trưởng', value: '+12%', color: 'sky' },
          { icon: Trophy, label: 'Kỷ lục tuần', value: '15,000', color: 'cyan' }
        ].map((stat, i) => (
          <div key={i} className="glass-dark p-6 rounded-[32px] border border-white/5">
            <div className={cn("p-3 rounded-2xl inline-flex mb-4", `bg-${stat.color}-500/10 text-${stat.color}-400`)}>
              <stat.icon className="h-6 w-6" />
            </div>
            <p className="text-[10px] font-black text-sky-300/40 uppercase tracking-widest">{stat.label}</p>
            <p className="text-2xl font-black text-white mt-1">{stat.value}</p>
          </div>
        ))}
      </div>

      {/* List */}
      <div className="glass-dark rounded-[40px] border border-white/5 overflow-hidden shadow-2xl">
        <div className="p-8 border-b border-white/5 flex items-center justify-between">
          <h3 className="text-xl font-black text-white">Top Học Viên</h3>
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-sky-300/40" />
            <input 
              type="text" 
              placeholder="Tìm kiếm..." 
              className="bg-sky-950/50 border border-sky-400/10 rounded-2xl pl-12 pr-6 py-3 text-sm text-white focus:outline-none focus:border-sky-400/50 transition-all"
            />
          </div>
        </div>
        <div className="divide-y divide-sky-400/10">
          {others.map((entry, i) => (
            <motion.div 
              key={entry.id}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="p-6 flex items-center gap-6 hover:bg-sky-400/5 transition-all group cursor-pointer"
            >
              <div className="w-10 text-center font-black text-sky-300/40 group-hover:text-sky-400 transition-colors">
                #{entry.rank}
              </div>
              <img src={entry.avatar} alt="" className="w-12 h-12 rounded-2xl border border-sky-400/10 shadow-lg" referrerPolicy="no-referrer" />
              <div className="flex-1">
                <p className="text-white font-bold group-hover:text-sky-300 transition-colors">{entry.fullName}</p>
                <p className="text-xs text-sky-300/40 font-medium">{entry.quizzesTaken} bài thi đã hoàn thành</p>
              </div>
              <div className="text-right">
                <p className="text-lg font-black text-white">{entry.totalScore.toLocaleString()}</p>
                <p className="text-[10px] font-black text-cyan-400 uppercase tracking-widest">Điểm</p>
              </div>
              <ChevronRight className="h-5 w-5 text-sky-900 group-hover:text-white transition-all group-hover:translate-x-1" />
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Leaderboard;
