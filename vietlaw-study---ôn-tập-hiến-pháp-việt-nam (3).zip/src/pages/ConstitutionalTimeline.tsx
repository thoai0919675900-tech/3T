import React from 'react';
import { 
  History, 
  Calendar, 
  ChevronRight, 
  FileText, 
  ArrowRight,
  Info,
  Clock,
  ShieldCheck
} from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../utils/utils';

const timelineData = [
  {
    year: '1946',
    title: 'Hiến pháp đầu tiên',
    description: 'Hiến pháp đầu tiên của nước Việt Nam Dân chủ Cộng hòa, khẳng định độc lập dân tộc và quyền tự do dân chủ.',
    color: 'bg-sky-700',
    details: 'Gồm 7 chương, 70 điều. Quy định Chính phủ là cơ quan hành chính cao nhất của toàn quốc.'
  },
  {
    year: '1959',
    title: 'Hiến pháp thời kỳ xây dựng XHCN',
    description: 'Phản ánh giai đoạn mới của cách mạng Việt Nam, xây dựng chủ nghĩa xã hội ở miền Bắc và đấu tranh thống nhất nước nhà.',
    color: 'bg-sky-600',
    details: 'Gồm 10 chương, 112 điều. Khẳng định vai trò lãnh đạo của Đảng Lao động Việt Nam.'
  },
  {
    year: '1980',
    title: 'Hiến pháp nước Việt Nam thống nhất',
    description: 'Ra đời sau khi đất nước hoàn toàn thống nhất, tập trung vào cơ chế "Đảng lãnh đạo, Nhà nước quản lý, Nhân dân làm chủ".',
    color: 'bg-sky-500',
    details: 'Gồm 12 chương, 147 điều. Thiết lập Hội đồng Nhà nước là cơ quan cao nhất.'
  },
  {
    year: '1992',
    title: 'Hiến pháp thời kỳ Đổi mới',
    description: 'Phục vụ công cuộc đổi mới toàn diện đất nước, chuyển sang nền kinh tế thị trường định hướng xã hội chủ nghĩa.',
    color: 'bg-cyan-500',
    details: 'Gồm 12 chương, 147 điều. Khẳng định quyền tự do kinh doanh và bảo hộ sở hữu tư nhân.'
  },
  {
    year: '2013',
    title: 'Hiến pháp hiện hành',
    description: 'Được thông qua tại Kỳ họp thứ 6, Quốc hội khóa XIII. Tập trung vào quyền con người, quyền và nghĩa vụ cơ bản của công dân.',
    color: 'bg-sky-400',
    details: 'Gồm 11 chương, 120 điều. Đề cao nguyên tắc kiểm soát quyền lực giữa các cơ quan nhà nước.'
  }
];

const ConstitutionalTimeline: React.FC = () => {
  return (
    <div className="max-w-5xl mx-auto space-y-12 pb-20">
      <header className="text-center space-y-4">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-sky-500/10 text-sky-400 text-[10px] font-black uppercase tracking-[0.2em] rounded-full border border-sky-500/20">
          <History className="h-3 w-3" />
          Dòng thời gian pháp lý
        </div>
        <h1 className="text-4xl md:text-5xl font-black text-white tracking-tight">
          Lịch sử <span className="text-gradient">Hiến pháp</span>
        </h1>
        <p className="text-sky-200/40 max-w-2xl mx-auto leading-relaxed">
          Khám phá quá trình hình thành và phát triển của các bản Hiến pháp Việt Nam qua các thời kỳ lịch sử quan trọng.
        </p>
      </header>

      <div className="relative">
        {/* Vertical Line */}
        <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-zinc-800 to-transparent hidden md:block" />

        <div className="space-y-16">
          {timelineData.map((item, idx) => (
            <motion.div
              key={item.year}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className={cn(
                "relative flex flex-col md:flex-row items-center gap-8 md:gap-0",
                idx % 2 === 0 ? "md:flex-row-reverse" : ""
              )}
            >
              {/* Year Bubble */}
              <div className="absolute left-8 md:left-1/2 -translate-x-1/2 z-20">
                <div className={cn(
                  "w-16 h-16 rounded-full flex items-center justify-center text-white font-black text-lg shadow-2xl border-4 border-zinc-950",
                  item.color
                )}>
                  {item.year}
                </div>
              </div>

              {/* Content Card */}
              <div className="w-full md:w-[45%] pl-20 md:pl-0">
                <div className="glass-dark p-8 rounded-[40px] border border-white/5 shadow-2xl hover:border-white/10 transition-all group">
                  <div className="flex items-center gap-3 mb-4">
                    <Calendar className="h-4 w-4 text-sky-300/40" />
                    <span className="text-[10px] font-black text-sky-300/40 uppercase tracking-widest">Năm {item.year}</span>
                  </div>
                  <h3 className="text-2xl font-black text-white mb-4 group-hover:text-sky-400 transition-colors">{item.title}</h3>
                  <p className="text-sky-100/60 leading-relaxed mb-6">
                    {item.description}
                  </p>
                  
                  <div className="p-4 bg-sky-400/5 rounded-2xl border border-sky-400/10 space-y-3">
                    <div className="flex items-start gap-3">
                      <Info className="h-4 w-4 text-sky-400 shrink-0 mt-0.5" />
                      <p className="text-xs text-sky-300/40 leading-relaxed">
                        {item.details}
                      </p>
                    </div>
                  </div>

                  <button className="mt-8 flex items-center gap-2 text-xs font-black text-sky-400 uppercase tracking-widest hover:text-sky-300 transition-colors">
                    Xem chi tiết bản Hiến pháp
                    <ArrowRight className="h-4 w-4" />
                  </button>
                </div>
              </div>

              {/* Spacer for the other side */}
              <div className="hidden md:block w-[45%]" />
            </motion.div>
          ))}
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { icon: FileText, label: 'Tổng số bản Hiến pháp', value: '05' },
          { icon: Clock, label: 'Thời gian phát triển', value: '77 năm' },
          { icon: ShieldCheck, label: 'Tính kế thừa', value: 'Cao' }
        ].map((stat, i) => (
          <div key={i} className="glass-dark p-6 rounded-[32px] border border-sky-400/10 flex items-center gap-6">
            <div className="p-4 bg-sky-500/10 rounded-2xl text-sky-400">
              <stat.icon className="h-6 w-6" />
            </div>
            <div>
              <p className="text-[10px] font-black text-sky-300/40 uppercase tracking-widest">{stat.label}</p>
              <p className="text-2xl font-black text-white">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ConstitutionalTimeline;
