import React, { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { 
  RotateCcw, 
  ChevronLeft, 
  ChevronRight, 
  CheckCircle, 
  CreditCard,
  Shuffle,
  BookOpen
} from 'lucide-react';
import { flashcards, chapters } from '../data/mockData';
import { useProgress } from '../context/ProgressContext';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../utils/utils';

const FlashcardsPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const { markFlashcardMastered, isFlashcardMastered } = useProgress();
  
  const chapterId = searchParams.get('chapter');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [shuffledCards, setShuffledCards] = useState(() => {
    const filtered = chapterId 
      ? flashcards.filter(f => f.chapterId === chapterId)
      : flashcards;
    return [...filtered];
  });

  const currentCard = shuffledCards[currentIndex];

  const handleNext = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentIndex((prev) => (prev + 1) % shuffledCards.length);
    }, 150);
  };

  const handlePrev = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentIndex((prev) => (prev - 1 + shuffledCards.length) % shuffledCards.length);
    }, 150);
  };

  const handleShuffle = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setShuffledCards([...shuffledCards].sort(() => Math.random() - 0.5));
      setCurrentIndex(0);
    }, 150);
  };

  const currentChapter = chapters.find(c => c.id === currentCard?.chapterId);

  if (shuffledCards.length === 0) {
    return (
      <div className="text-center py-20">
        <div className="p-6 bg-white/5 rounded-full inline-flex mb-6">
          <CreditCard className="h-12 w-12 text-zinc-700" />
        </div>
        <h2 className="text-2xl font-bold text-white">Không có flashcards nào</h2>
        <p className="text-zinc-500 mt-2">Vui lòng chọn chương khác hoặc quay lại sau.</p>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-10 pb-20">
      <header className="text-center space-y-4">
        <span className="px-4 py-1.5 bg-sky-500/10 text-sky-400 text-xs font-black uppercase tracking-[0.2em] rounded-full border border-sky-500/20">
          Ghi nhớ điều luật
        </span>
        <h1 className="text-4xl md:text-5xl font-black text-white tracking-tight">
          Thẻ <span className="text-gradient">Ghi nhớ</span>
        </h1>
        <p className="text-sky-200/60 max-w-lg mx-auto leading-relaxed">
          Lật thẻ để xem nội dung chi tiết của từng điều luật. Sử dụng phương pháp lặp lại ngắt quãng để ghi nhớ hiệu quả.
        </p>
      </header>

      <div className="flex items-center justify-between glass-dark p-6 rounded-[32px] border border-sky-400/10 shadow-2xl">
        <div className="flex items-center gap-4">
          <div className="p-3 rounded-2xl bg-sky-600 text-white shadow-lg shadow-sky-600/20">
            <BookOpen className="h-6 w-6" />
          </div>
          <div>
            <p className="text-[10px] font-black text-sky-300/40 uppercase tracking-widest">Chuyên đề</p>
            <p className="text-sm font-bold text-white truncate max-w-[200px] md:max-w-[300px]">
              {currentChapter?.title.split(':')[0]}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-6">
          <div className="text-right">
            <p className="text-[10px] font-black text-sky-300/40 uppercase tracking-widest">Tiến độ</p>
            <p className="text-sm font-black text-sky-400">
              {currentIndex + 1} <span className="text-sky-300/20">/</span> {shuffledCards.length}
            </p>
          </div>
          <button 
            onClick={handleShuffle}
            className="p-3 bg-sky-400/5 hover:bg-sky-400/10 rounded-2xl text-sky-300/40 hover:text-white transition-all group"
            title="Trộn thẻ"
          >
            <Shuffle className="h-5 w-5 group-hover:rotate-180 transition-transform duration-500" />
          </button>
        </div>
      </div>

      <div className="perspective-1000 h-[450px] relative group">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentCard.id}
            initial={{ opacity: 0, scale: 0.9, rotateY: isFlipped ? 180 : 0 }}
            animate={{ opacity: 1, scale: 1, rotateY: isFlipped ? 180 : 0 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.6, type: 'spring', stiffness: 200, damping: 25 }}
            className="w-full h-full cursor-pointer preserve-3d relative"
            onClick={() => setIsFlipped(!isFlipped)}
          >
            {/* Front Side */}
            <div className={cn(
              "absolute inset-0 backface-hidden bg-sky-950/20 rounded-[40px] border border-sky-400/10 shadow-2xl flex flex-col items-center justify-center p-12 text-center transition-all group-hover:border-sky-400/30",
              isFlipped && "hidden"
            )}>
              <div className="absolute inset-0 bg-gradient-to-br from-sky-600/5 to-transparent pointer-events-none" />
              <div className="p-6 bg-sky-600/10 rounded-3xl mb-8 group-hover:scale-110 transition-transform duration-500">
                <CreditCard className="h-16 w-16 text-sky-400" />
              </div>
              <h2 className="text-6xl font-black text-white mb-6 tracking-tighter">
                {currentCard.articleNumber}
              </h2>
              <div className="px-6 py-2 bg-sky-400/5 rounded-full border border-sky-400/10">
                <p className="text-sky-300/40 text-xs font-black uppercase tracking-[0.2em]">
                  Nhấn để lật thẻ
                </p>
              </div>
            </div>

            {/* Back Side */}
            <div className={cn(
              "absolute inset-0 backface-hidden bg-sky-600 rounded-[40px] shadow-2xl flex flex-col items-center justify-center p-12 text-center rotate-y-180",
              !isFlipped && "hidden"
            )}>
              <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10" />
              <div className="absolute top-10 left-10 text-white/40 text-xs font-black uppercase tracking-[0.2em]">
                {currentCard.articleNumber}
              </div>
              <p className="text-white text-2xl md:text-3xl font-bold leading-relaxed relative z-10">
                {currentCard.content}
              </p>
              <div className="absolute bottom-10 right-10 text-white/40 text-xs font-black uppercase tracking-[0.2em]">
                Hiến pháp 2013
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="flex items-center justify-center gap-8">
        <button
          onClick={handlePrev}
          className="p-5 rounded-3xl bg-sky-950/20 border border-sky-400/10 text-sky-300/40 hover:text-white hover:border-sky-400/50 transition-all shadow-xl active:scale-90"
        >
          <ChevronLeft className="h-7 w-7" />
        </button>
        
        <button
          onClick={(e) => {
            e.stopPropagation();
            markFlashcardMastered(currentCard.id);
          }}
          className={cn(
            "flex items-center gap-3 px-10 py-5 rounded-3xl font-black uppercase tracking-widest text-sm transition-all shadow-2xl active:scale-95",
            isFlashcardMastered(currentCard.id)
              ? "bg-cyan-600 text-white shadow-cyan-600/20"
              : "bg-white text-zinc-950 hover:bg-sky-500 hover:text-white"
          )}
        >
          <CheckCircle className="h-5 w-5" />
          {isFlashcardMastered(currentCard.id) ? 'Đã thuộc' : 'Đánh dấu đã thuộc'}
        </button>

        <button
          onClick={handleNext}
          className="p-5 rounded-3xl bg-sky-950/20 border border-sky-400/10 text-sky-300/40 hover:text-white hover:border-sky-400/50 transition-all shadow-xl active:scale-90"
        >
          <ChevronRight className="h-7 w-7" />
        </button>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-dark p-8 rounded-[32px] border border-sky-400/10 flex items-start gap-6"
      >
        <div className="p-4 bg-sky-600/20 rounded-2xl text-sky-400 shrink-0">
          <RotateCcw className="h-6 w-6" />
        </div>
        <div>
          <h4 className="text-lg font-bold text-white">Mẹo học tập</h4>
          <p className="text-sky-200/60 mt-2 leading-relaxed">
            Hãy cố gắng nhớ nội dung điều luật trước khi lật thẻ. Việc lặp lại ngắt quãng (Spaced Repetition) sẽ giúp bạn ghi nhớ lâu hơn và sâu sắc hơn.
          </p>
        </div>
      </motion.div>
    </div>
  );
};

export default FlashcardsPage;
